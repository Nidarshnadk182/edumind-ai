import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/auth/session';

export default async function DashboardRedirectPage() {
  const session = await getSessionUser();
  if (!session) {
    redirect('/login');
  }
  if (!session.profile.onboarding_completed) redirect('/onboarding');
  redirect(`/${session.profile.role}/dashboard`);
}
