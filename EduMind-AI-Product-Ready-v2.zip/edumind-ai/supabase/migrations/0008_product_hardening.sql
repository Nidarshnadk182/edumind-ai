-- EduMind AI product hardening.
-- Run after 0007_complete_school_workflow.sql.

alter table subject_resources
  add column if not exists target_student_profile_id uuid
  references student_profiles(id) on delete cascade;

create table if not exists teacher_assignments (
  id uuid primary key default uuid_generate_v4(),
  teacher_profile_id uuid not null references teacher_profiles(id) on delete cascade,
  subject_name text not null,
  chapter_name text,
  title text not null,
  instructions text not null,
  due_at timestamptz,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

alter table teacher_assignments enable row level security;

drop policy if exists "teacher assignments manage own" on teacher_assignments;
create policy "teacher assignments manage own"
on teacher_assignments
for all
using (
  exists (
    select 1 from teacher_profiles tp
    where tp.id = teacher_assignments.teacher_profile_id
      and tp.profile_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from teacher_profiles tp
    where tp.id = teacher_assignments.teacher_profile_id
      and tp.profile_id = auth.uid()
  )
);

drop policy if exists "students read published assignments" on teacher_assignments;
create policy "students read published assignments"
on teacher_assignments
for select
using (is_published = true and auth.uid() is not null);

-- Restrict corrected papers to the target student, while allowing other shared materials.
drop policy if exists "shared resources" on subject_resources;
create policy "shared resources"
on subject_resources
for select
using (
  owner_profile_id = auth.uid()
  or (
    target_student_profile_id is null
    and visibility in ('class','student','institution')
    and auth.uid() is not null
  )
  or exists (
    select 1 from student_profiles sp
    where sp.id = subject_resources.target_student_profile_id
      and sp.profile_id = auth.uid()
  )
);

-- Teachers can read prediction snapshots for students in one of their classes.
drop policy if exists "teachers read taught student predictions" on student_prediction_snapshots;
create policy "teachers read taught student predictions"
on student_prediction_snapshots
for select
using (
  exists (
    select 1
    from student_profiles sp
    join class_members cm on cm.student_id = sp.id
    join classes c on c.id = cm.class_id
    join teacher_profiles tp on tp.id = c.teacher_id
    where sp.profile_id = student_prediction_snapshots.student_id
      and tp.profile_id = auth.uid()
  )
);

-- Parent dashboard: child identity + marks + latest prediction.
create or replace function public.get_parent_child_overview()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  me_role user_role;
  child_profile_id uuid;
  child_student_id uuid;
  child_json jsonb;
  marks_json jsonb;
  prediction_json jsonb;
  avg_marks numeric;
begin
  select role into me_role from profiles where id = auth.uid();
  if me_role is distinct from 'parent'::user_role then
    raise exception 'Parent access required';
  end if;

  select l.student_profile_id
  into child_profile_id
  from parent_student_links l
  where l.parent_profile_id = auth.uid()
    and l.consent_confirmed = true
  order by l.linked_at desc
  limit 1;

  if child_profile_id is null then
    return jsonb_build_object('student', null);
  end if;

  select sp.id
  into child_student_id
  from student_profiles sp
  where sp.profile_id = child_profile_id;

  select jsonb_build_object(
    'fullName', p.full_name,
    'registerNumber', sp.register_number,
    'standardName', sp.standard_name,
    'sectionName', sp.section_name
  )
  into child_json
  from profiles p
  join student_profiles sp on sp.profile_id = p.id
  where p.id = child_profile_id;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', m.id,
        'subject', m.subject_name,
        'assessment', m.assessment_name,
        'score', m.score,
        'maxScore', m.max_score,
        'date', m.assessment_date
      )
      order by m.assessment_date desc
    ),
    '[]'::jsonb
  )
  into marks_json
  from (
    select *
    from student_subject_marks
    where student_profile_id = child_student_id
    order by assessment_date desc
    limit 10
  ) m;

  select round(avg((score / nullif(max_score,0)) * 100), 0)
  into avg_marks
  from student_subject_marks
  where student_profile_id = child_student_id;

  select jsonb_build_object(
    'expectedScore', round(s.expected_score,0),
    'scoreLow', round(s.score_low,0),
    'scoreHigh', round(s.score_high,0),
    'passProbability', round(s.pass_probability,0),
    'readinessScore', round(s.readiness_score,0),
    'riskLevel', s.risk_level,
    'createdAt', s.created_at
  )
  into prediction_json
  from student_prediction_snapshots s
  where s.student_id = child_profile_id
  order by s.created_at desc
  limit 1;

  return jsonb_build_object(
    'student', child_json,
    'averageMarks', avg_marks,
    'marks', marks_json,
    'prediction', prediction_json
  );
end;
$$;

grant execute on function public.get_parent_child_overview() to authenticated;

-- Institution dashboard: only statistics for the institution administered by the current account.
create or replace function public.get_institution_overview()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  me_role user_role;
  inst_id uuid;
  teacher_count integer;
  class_count integer;
  student_count integer;
  assessment_count integer;
begin
  select role into me_role from profiles where id = auth.uid();
  if me_role is distinct from 'institution'::user_role then
    raise exception 'Institution access required';
  end if;

  select id into inst_id
  from institutions
  where admin_profile_id = auth.uid()
  order by created_at asc
  limit 1;

  if inst_id is null then
    return jsonb_build_object(
      'teachers', 0,
      'classes', 0,
      'students', 0,
      'assessments', 0
    );
  end if;

  select count(*) into teacher_count
  from teacher_profiles
  where institution_id = inst_id;

  select count(*) into class_count
  from classes
  where institution_id = inst_id
    and archived_at is null;

  select count(distinct cm.student_id) into student_count
  from class_members cm
  join classes c on c.id = cm.class_id
  where c.institution_id = inst_id
    and c.archived_at is null;

  select count(*) into assessment_count
  from student_subject_marks sm
  join teacher_profiles tp on tp.id = sm.teacher_profile_id
  where tp.institution_id = inst_id;

  return jsonb_build_object(
    'teachers', teacher_count,
    'classes', class_count,
    'students', student_count,
    'assessments', assessment_count
  );
end;
$$;

grant execute on function public.get_institution_overview() to authenticated;
