'use client';

import { Suspense, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Brain, Eye, EyeOff, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  createSupabaseBrowserClient,
  isSupabaseConfigured,
} from '@/lib/database/supabase-browser';
import type { UserRole } from '@/types/database';

const VALID_ROLES: UserRole[] = ['student', 'teacher', 'parent', 'institution'];

function AuthForm() {
  const router = useRouter();
  const params = useSearchParams();
  const requestedRole = params.get('role') as UserRole | null;
  const role =
    requestedRole && VALID_ROLES.includes(requestedRole)
      ? requestedRole
      : null;

  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  if (!role) {
    return (
      <main className="grid min-h-screen place-items-center bg-canvas-light px-6">
        <section className="card max-w-md p-7 text-center">
          <h1 className="font-display text-xl font-semibold">Choose your role first</h1>
          <p className="mt-2 text-sm text-navy-500">
            EduMind AI needs to know whether you are a student, teacher, parent or administrator.
          </p>
          <Link
            href="/"
            className="mt-5 inline-flex rounded-xl bg-purple-600 px-5 py-2.5 text-sm font-medium text-white"
          >
            Choose role
          </Link>
        </section>
      </main>
    );
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    if (!isSupabaseConfigured()) {
      setError('Supabase is not configured. Add your Supabase environment variables in Vercel.');
      return;
    }

    if (mode === 'signup') {
      if (!fullName.trim()) return setError('Please enter your full name.');
      if (password.length < 8) return setError('Password must contain at least 8 characters.');
      if (password !== confirm) return setError('Passwords do not match.');
    }

    setLoading(true);

    try {
      const supabase = createSupabaseBrowserClient();
      const cleanEmail = email.trim().toLowerCase();

      if (mode === 'login') {
        const { data, error: authError } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });

        if (authError || !data.user) {
          setError('The email or password is incorrect.');
          return;
        }

        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('role,onboarding_completed')
          .eq('id', data.user.id)
          .maybeSingle();

        if (profileError || !profile) {
          setError('Your EduMind profile could not be found.');
          return;
        }

        if (profile.role !== role) {
          setError(
            `This account is registered as ${profile.role}. Go back and select that role before logging in.`
          );
          return;
        }

        router.replace(profile.onboarding_completed ? '/dashboard' : '/onboarding');
        router.refresh();
        return;
      }

      const { data, error: signUpError } = await supabase.auth.signUp({
        email: cleanEmail,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback?next=/onboarding`,
          data: {
            full_name: fullName.trim(),
            role,
          },
        },
      });

      if (signUpError || !data.user) {
        setError(signUpError?.message ?? 'Could not create your account.');
        return;
      }

      if (data.session) {
        router.replace('/onboarding');
        router.refresh();
        return;
      }

      setMessage(
        'Your account was created. Check your email and confirm it, then log in using the same role.'
      );
    } catch (authError) {
      console.error(authError);
      setError('Something went wrong while contacting the authentication service.');
    } finally {
      setLoading(false);
    }
  }

  const roleLabel = role === 'institution' ? 'Institution / Administrator' : role;

  return (
    <main className="min-h-screen bg-canvas-light px-6 py-12">
      <div className="mx-auto flex min-h-[calc(100vh-6rem)] max-w-md items-center">
        <div className="w-full">
          <Link
            href="/"
            className="mb-7 flex items-center justify-center gap-2 font-display font-semibold text-navy-900"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600 text-white">
              <Brain className="h-5 w-5" />
            </span>
            EduMind AI
          </Link>

          <section className="card p-7">
            <div className="mb-5 rounded-xl bg-purple-50 px-4 py-3 text-sm text-purple-800">
              Continuing as <strong className="capitalize">{roleLabel}</strong>
              {' · '}
              <Link href="/" className="underline">change role</Link>
            </div>

            <div className="mb-6 grid grid-cols-2 rounded-xl bg-navy-50 p-1">
              <button
                type="button"
                onClick={() => { setMode('login'); setError(null); setMessage(null); }}
                className={`rounded-lg px-3 py-2 text-sm font-medium ${
                  mode === 'login' ? 'bg-white text-purple-700 shadow-sm' : 'text-navy-500'
                }`}
              >
                Log in
              </button>
              <button
                type="button"
                onClick={() => { setMode('signup'); setError(null); setMessage(null); }}
                className={`rounded-lg px-3 py-2 text-sm font-medium ${
                  mode === 'signup' ? 'bg-white text-purple-700 shadow-sm' : 'text-navy-500'
                }`}
              >
                Sign up
              </button>
            </div>

            <h1 className="font-display text-xl font-semibold text-navy-900">
              {mode === 'login' ? 'Welcome back' : 'Create your account'}
            </h1>
            <p className="mb-5 mt-1 text-sm text-navy-500">
              {mode === 'login'
                ? 'Enter your account email and password.'
                : 'Create your login first. Your role-specific information is collected next.'}
            </p>

            {error && (
              <div className="mb-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
            )}
            {message && (
              <div className="mb-4 rounded-xl bg-green-50 px-4 py-3 text-sm text-green-800">{message}</div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <Field label="Full name" value={fullName} onChange={setFullName} />
              )}

              <Field
                label="Email address"
                value={email}
                onChange={setEmail}
                type="email"
                placeholder="you@example.com"
              />

              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <label className="text-sm font-medium text-navy-700">Password</label>
                  {mode === 'login' && (
                    <Link
                      href={`/forgot-password?role=${role}`}
                      className="text-xs font-medium text-purple-600 hover:underline"
                    >
                      Forgot password?
                    </Link>
                  )}
                </div>
                <div className="relative">
                  <input
                    required
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-navy-200 px-3.5 py-2.5 pr-11 text-sm focus:outline-none focus:ring-2 focus:ring-purple-300"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-navy-400"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {mode === 'signup' && (
                <Field
                  label="Confirm password"
                  value={confirm}
                  onChange={setConfirm}
                  type={showPassword ? 'text' : 'password'}
                />
              )}

              <Button type="submit" className="w-full" disabled={loading}>
                {loading
                  ? <Loader2 className="h-4 w-4 animate-spin" />
                  : mode === 'login'
                    ? 'Log in'
                    : 'Create account'}
              </Button>
            </form>
          </section>
        </div>
      </div>
    </main>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-navy-700">{label}</label>
      <input
        required
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-navy-200 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-300"
      />
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="grid min-h-screen place-items-center"><Loader2 className="h-6 w-6 animate-spin" /></div>}>
      <AuthForm />
    </Suspense>
  );
}
