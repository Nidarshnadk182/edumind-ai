import Link from 'next/link';
import { Award, Target, TrendingUp, BookOpen, ArrowRight } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

export default async function StudentDashboardPage() {
  const session = await requireRole(['student']);
  const supabase = createSupabaseServerClient();

  const { data: student } = await supabase
    .from('student_profiles')
    .select('id,register_number,standard_name,section_name,subjects,difficult_subjects,difficult_topics')
    .eq('profile_id', session.id)
    .maybeSingle();

  let averageMarks: number | null = null;
  let latestPrediction: any = null;
  let marks: any[] = [];

  if (student) {
    const { data: markRows } = await supabase
      .from('student_subject_marks')
      .select('id,subject_name,assessment_name,score,max_score,assessment_date')
      .eq('student_profile_id', student.id)
      .order('assessment_date', { ascending: false });

    marks = markRows ?? [];

    const percentages = marks
      .filter((item: any) => Number(item.max_score) > 0)
      .map((item: any) => (Number(item.score) / Number(item.max_score)) * 100);

    if (percentages.length) {
      averageMarks = Math.round(
        percentages.reduce((sum: number, value: number) => sum + value, 0) / percentages.length
      );
    }

    const { data: prediction } = await supabase
      .from('student_prediction_snapshots')
      .select('*')
      .eq('student_id', session.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    latestPrediction = prediction;
  }

  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm text-navy-500">Welcome back,</p>
        <h1 className="font-display text-2xl font-semibold">{session.profile.full_name}</h1>
        {student && (
          <p className="mt-1 text-xs text-navy-500">
            {[student.standard_name, student.section_name, student.register_number].filter(Boolean).join(' · ')}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={Award} label="Average recorded marks" value={averageMarks === null ? '—' : `${averageMarks}%`} />
        <Stat icon={TrendingUp} label="Predicted next score" value={latestPrediction ? `${Math.round(Number(latestPrediction.expected_score))}%` : 'Need more data'} />
        <Stat icon={Target} label="Readiness" value={latestPrediction ? `${Math.round(Number(latestPrediction.readiness_score))}%` : '—'} />
        <Stat icon={BookOpen} label="Subjects registered" value={String(student?.subjects?.length ?? 0)} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle>Your subjects</CardTitle>
          <CardDescription>Subjects saved during student registration.</CardDescription>
          {student?.subjects?.length ? (
            <div className="mt-4 flex flex-wrap gap-2">
              {student.subjects.map((subject: string) => (
                <span key={subject} className="rounded-full bg-purple-50 px-3 py-1.5 text-xs font-medium text-purple-700">
                  {subject}
                </span>
              ))}
            </div>
          ) : (
            <p className="mt-4 text-sm text-navy-500">No subjects have been added yet.</p>
          )}
        </Card>

        <Card>
          <CardTitle>Subjects you find difficult</CardTitle>
          <CardDescription>EduMind uses these together with your actual test performance.</CardDescription>
          {student?.difficult_subjects?.length ? (
            <div className="mt-4 flex flex-wrap gap-2">
              {student.difficult_subjects.map((subject: string) => (
                <span key={subject} className="rounded-full bg-red-50 px-3 py-1.5 text-xs font-medium text-red-700">
                  {subject}
                </span>
              ))}
            </div>
          ) : (
            <p className="mt-4 text-sm text-navy-500">No difficult subjects have been marked.</p>
          )}
        </Card>
      </div>

      <Card>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Recent teacher-entered marks</CardTitle>
            <CardDescription>These scores feed future-score prediction and adaptive study recommendations.</CardDescription>
          </div>
          <Link href="/student/quizzes" className="inline-flex items-center gap-1 text-sm font-medium text-purple-600">
            Practise <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        {marks.length ? (
          <div className="mt-4 divide-y divide-navy-100">
            {marks.slice(0, 6).map((mark: any) => (
              <div key={mark.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium">{mark.subject_name}</p>
                  <p className="text-xs text-navy-500">{mark.assessment_name}</p>
                </div>
                <p className="text-sm font-semibold">{mark.score}/{mark.max_score}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-4 text-sm text-navy-500">
            No marks have been entered yet. Predictions will become meaningful once the system has assessment data.
          </p>
        )}
      </Card>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Award; label: string; value: string }) {
  return (
    <Card className="!p-5">
      <Icon className="mb-3 h-5 w-5 text-purple-600" />
      <p className="font-display text-lg font-semibold">{value}</p>
      <p className="text-xs text-navy-500">{label}</p>
    </Card>
  );
}
