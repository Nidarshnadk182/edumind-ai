import { NextResponse } from 'next/server';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

export async function GET(request: Request) {
  const supabase = createSupabaseServerClient();
  await supabase.auth.signOut();
  return NextResponse.redirect(new URL('/', request.url));
}
