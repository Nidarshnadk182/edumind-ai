import { Award, TrendingUp, Target, BookOpen } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

export default async function ParentDashboardPage() {
  await requireRole(['parent']);
  const supabase = createSupabaseServerClient();
  const { data, error } = await supabase.rpc('get_parent_child_overview');

  const overview: any = data ?? null;

  return (
    <div className="space-y-7 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl font-semibold">Parent Dashboard</h1>
        <p className="text-sm text-navy-500">
          View the linked student's academic progress. Private AI conversations are not shown.
        </p>
      </div>

      {error && (
        <Card>
          <CardTitle>Could not load child data</CardTitle>
          <CardDescription>{error.message}</CardDescription>
        </Card>
      )}

      {!error && !overview?.student && (
        <Card>
          <CardTitle>No child linked yet</CardTitle>
          <CardDescription>
            Link the parent's account to a student's register number during parent onboarding.
          </CardDescription>
        </Card>
      )}

      {overview?.student && (
        <>
          <Card>
            <CardTitle>{overview.student.fullName}</CardTitle>
            <CardDescription>
              {[overview.student.standardName, overview.student.sectionName, overview.student.registerNumber]
                .filter(Boolean)
                .join(' · ')}
            </CardDescription>
          </Card>

          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Stat label="Average recorded marks" value={overview.averageMarks === null ? '—' : `${overview.averageMarks}%`} icon={Award} />
            <Stat label="Predicted next score" value={overview.prediction ? `${overview.prediction.expectedScore}%` : 'Not enough data'} icon={TrendingUp} />
            <Stat label="Readiness" value={overview.prediction ? `${overview.prediction.readinessScore}%` : '—'} icon={Target} />
            <Stat label="Risk level" value={overview.prediction?.riskLevel ?? '—'} icon={BookOpen} />
          </div>

          <Card>
            <CardTitle>Recent marks</CardTitle>
            {overview.marks?.length ? (
              <div className="mt-3 divide-y divide-navy-100">
                {overview.marks.map((mark: any) => (
                  <div key={mark.id} className="flex justify-between py-3 text-sm">
                    <div>
                      <p className="font-medium">{mark.subject}</p>
                      <p className="text-xs text-navy-500">{mark.assessment}</p>
                    </div>
                    <p className="font-semibold">{mark.score}/{mark.maxScore}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm text-navy-500">No teacher-entered marks yet.</p>
            )}
          </Card>

          {overview.prediction && (
            <Card>
              <CardTitle>Future-test prediction</CardTitle>
              <CardDescription>
                This is an estimate based on the student's recorded academic progress, not a guaranteed mark.
              </CardDescription>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <Small label="Expected score" value={`${overview.prediction.expectedScore}%`} />
                <Small label="Expected range" value={`${overview.prediction.scoreLow}% – ${overview.prediction.scoreHigh}%`} />
                <Small label="Pass probability" value={`${overview.prediction.passProbability}%`} />
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

function Stat({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Award }) {
  return (
    <Card className="!p-5">
      <Icon className="mb-3 h-5 w-5 text-purple-600" />
      <p className="font-display text-lg font-semibold capitalize">{value}</p>
      <p className="text-xs text-navy-500">{label}</p>
    </Card>
  );
}

function Small({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-purple-50 p-4">
      <p className="text-xs text-navy-500">{label}</p>
      <p className="mt-1 font-semibold text-purple-800">{value}</p>
    </div>
  );
}
