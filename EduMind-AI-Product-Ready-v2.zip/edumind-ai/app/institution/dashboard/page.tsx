import { Users, GraduationCap, BookOpen, Activity } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

export default async function InstitutionDashboardPage() {
  const session = await requireRole(['institution']);
  const supabase = createSupabaseServerClient();
  const { data, error } = await supabase.rpc('get_institution_overview');
  const overview: any = data ?? {};

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold">Institution Overview</h1>
        <p className="text-sm text-navy-500">
          Live information from the institution's EduMind records. No sample counts are displayed.
        </p>
      </div>

      {error && (
        <Card>
          <CardTitle>Could not load institution analytics</CardTitle>
          <CardDescription>{error.message}</CardDescription>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={GraduationCap} label="Students in institution classes" value={String(overview.students ?? 0)} />
        <Stat icon={Users} label="Teachers" value={String(overview.teachers ?? 0)} />
        <Stat icon={BookOpen} label="Classes" value={String(overview.classes ?? 0)} />
        <Stat icon={Activity} label="Recorded assessments" value={String(overview.assessments ?? 0)} />
      </div>

      <Card>
        <CardTitle>Administrator</CardTitle>
        <CardDescription>{session.profile.full_name}</CardDescription>
        <p className="mt-3 text-sm text-navy-500">
          Institution analytics will grow automatically as teachers create classes and enter student academic data.
        </p>
      </Card>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Users; label: string; value: string }) {
  return (
    <Card className="!p-5">
      <span className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
        <Icon className="h-4.5 w-4.5" />
      </span>
      <p className="font-display text-xl font-semibold">{value}</p>
      <p className="text-xs text-navy-500">{label}</p>
    </Card>
  );
}
