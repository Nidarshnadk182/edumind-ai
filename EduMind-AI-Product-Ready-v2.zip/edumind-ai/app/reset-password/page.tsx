'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Brain, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { createSupabaseBrowserClient } from '@/lib/database/supabase-browser';

export default function ResetPasswordPage() {
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const supabase = createSupabaseBrowserClient();
    supabase.auth.getUser().then(({ data }) => {
      setReady(Boolean(data.user));
      if (!data.user) {
        setError('This reset link is invalid or has expired. Request a new password-reset email.');
      }
    });
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);

    if (password.length < 8) {
      setError('Your new password must contain at least 8 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      const supabase = createSupabaseBrowserClient();
      const { error: updateError } = await supabase.auth.updateUser({ password });

      if (updateError) {
        setError(updateError.message);
        return;
      }

      setDone(true);
    } catch {
      setError('Could not update the password. Please request a new reset link.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-canvas-light px-6 py-12">
      <div className="w-full max-w-md">
        <div className="mb-7 flex items-center justify-center gap-2 font-display font-semibold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600 text-white">
            <Brain className="h-5 w-5" />
          </span>
          EduMind AI
        </div>

        <section className="card p-7">
          <h1 className="font-display text-xl font-semibold">Choose a new password</h1>
          <p className="mb-5 mt-2 text-sm text-navy-500">
            Enter a new password for your EduMind account.
          </p>

          {error && <p className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}

          {done ? (
            <div>
              <p className="rounded-xl bg-green-50 p-3 text-sm text-green-800">
                Your password has been updated successfully.
              </p>
              <Link href="/" className="mt-5 block text-center text-sm font-medium text-purple-600">
                Return to EduMind AI
              </Link>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">New password</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={!ready}
                  className="w-full rounded-xl border border-navy-200 px-3.5 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium">Confirm new password</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  disabled={!ready}
                  className="w-full rounded-xl border border-navy-200 px-3.5 py-2.5 text-sm"
                />
              </div>
              <Button className="w-full" disabled={!ready || loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Update password'}
              </Button>
            </form>
          )}
        </section>
      </div>
    </main>
  );
}
