import Link from 'next/link';
import {
  Brain,
  GraduationCap,
  School,
  Users,
  Building2,
  ArrowRight,
} from 'lucide-react';

const ROLES = [
  {
    key: 'student',
    title: 'Student',
    description: 'Learn with the AI Tutor, take tests, upload your own study material and receive a personalised study path.',
    icon: GraduationCap,
  },
  {
    key: 'teacher',
    title: 'Teacher',
    description: 'Create classes, enter marks, add study material, publish assignments and tests, and monitor progress.',
    icon: School,
  },
  {
    key: 'parent',
    title: 'Parent',
    description: "Link to your child's account and view academic progress and future-score predictions.",
    icon: Users,
  },
  {
    key: 'institution',
    title: 'Institution / Administrator',
    description: 'Set up the institution and monitor teachers, students, classes and academic performance.',
    icon: Building2,
  },
] as const;

export default function HomePage() {
  return (
    <main className="min-h-screen bg-canvas-light px-6 py-12">
      <div className="mx-auto max-w-5xl">
        <div className="mb-9 flex items-center justify-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-600 text-white">
            <Brain className="h-6 w-6" />
          </span>
          <div>
            <h1 className="font-display text-2xl font-semibold text-navy-900">EduMind AI</h1>
            <p className="text-xs text-navy-500">Adaptive academic learning platform</p>
          </div>
        </div>

        <section className="card p-7 md:p-10">
          <div className="mx-auto mb-8 max-w-2xl text-center">
            <p className="text-xs font-semibold uppercase tracking-[.18em] text-purple-600">
              Select your role
            </p>
            <h2 className="mt-2 font-display text-3xl font-semibold text-navy-900">
              Who are you?
            </h2>
            <p className="mt-3 text-sm leading-6 text-navy-500">
              Choose your role first. The next page will give you Log in and Sign up.
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {ROLES.map(({ key, title, description, icon: Icon }) => (
              <Link
                key={key}
                href={`/login?role=${key}`}
                className="group rounded-2xl border border-navy-200 bg-white p-5 transition hover:border-purple-400 hover:shadow-sm"
              >
                <div className="flex items-start gap-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-purple-50 text-purple-600">
                    <Icon className="h-5 w-5" />
                  </span>
                  <div className="flex-1">
                    <h3 className="font-display font-semibold text-navy-900">{title}</h3>
                    <p className="mt-1 text-sm leading-6 text-navy-500">{description}</p>
                  </div>
                  <ArrowRight className="mt-2 h-4 w-4 text-navy-300 transition group-hover:translate-x-1 group-hover:text-purple-600" />
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
