import { NextResponse } from 'next/server';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

function generateClassCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i += 1) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

function slugify(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80);
}

export async function GET() {
  const session = await requireRole(['teacher']).catch(() => null);
  if (!session) {
    return NextResponse.json({ success: false, error: { message: 'Teacher access required.' } }, { status: 403 });
  }

  const supabase = createSupabaseServerClient();
  const { data: teacher } = await supabase
    .from('teacher_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!teacher) {
    return NextResponse.json({ success: false, error: { message: 'Complete teacher onboarding first.' } }, { status: 400 });
  }

  const { data: classes, error } = await supabase
    .from('classes')
    .select('id,name,class_code,academic_year,academic_term,programme,section_name,subject_id,subjects(name)')
    .eq('teacher_id', teacher.id)
    .is('archived_at', null)
    .order('created_at', { ascending: false });

  if (error) {
    return NextResponse.json({ success: false, error: { message: error.message } }, { status: 500 });
  }

  const classIds = (classes ?? []).map((item: any) => item.id);
  let memberCounts: Record<string, number> = {};

  if (classIds.length) {
    const { data: memberships } = await supabase
      .from('class_members')
      .select('class_id')
      .in('class_id', classIds);

    memberCounts = (memberships ?? []).reduce((acc: Record<string, number>, row: any) => {
      acc[row.class_id] = (acc[row.class_id] ?? 0) + 1;
      return acc;
    }, {});
  }

  return NextResponse.json({
    success: true,
    data: (classes ?? []).map((item: any) => ({
      id: item.id,
      name: item.name,
      classCode: item.class_code,
      academicYear: item.academic_year,
      academicTerm: item.academic_term,
      programme: item.programme,
      sectionName: item.section_name,
      subjectName: item.subjects?.name ?? 'Subject',
      students: memberCounts[item.id] ?? 0,
    })),
  });
}

export async function POST(request: Request) {
  const session = await requireRole(['teacher']).catch(() => null);
  if (!session) {
    return NextResponse.json({ success: false, error: { message: 'Teacher access required.' } }, { status: 403 });
  }

  const body = await request.json().catch(() => null);
  const name = String(body?.name ?? '').trim();
  const subjectName = String(body?.subjectName ?? '').trim();

  if (name.length < 2 || subjectName.length < 2) {
    return NextResponse.json(
      { success: false, error: { message: 'Class name and subject are required.' } },
      { status: 400 }
    );
  }

  const supabase = createSupabaseServerClient();
  const { data: teacher } = await supabase
    .from('teacher_profiles')
    .select('id,institution_id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!teacher) {
    return NextResponse.json(
      { success: false, error: { message: 'Complete teacher onboarding first.' } },
      { status: 400 }
    );
  }

  const baseSlug = slugify(subjectName) || 'subject';
  let { data: subject } = await supabase
    .from('subjects')
    .select('id,name')
    .ilike('name', subjectName)
    .maybeSingle();

  if (!subject) {
    const { data: createdSubject, error: subjectError } = await supabase
      .from('subjects')
      .insert({
        name: subjectName,
        slug: `${baseSlug}-${Math.random().toString(36).slice(2, 6)}`,
      })
      .select('id,name')
      .single();

    if (subjectError) {
      return NextResponse.json(
        { success: false, error: { message: `Could not create subject: ${subjectError.message}` } },
        { status: 500 }
      );
    }

    subject = createdSubject;
  }

  const classCode = generateClassCode();

  const { data, error } = await supabase
    .from('classes')
    .insert({
      name,
      subject_id: subject.id,
      teacher_id: teacher.id,
      class_code: classCode,
      institution_id: teacher.institution_id,
      academic_year: body?.academicYear?.trim() || null,
      academic_term: body?.academicTerm?.trim() || null,
      programme: body?.programme?.trim() || null,
      section_name: body?.sectionName?.trim() || null,
    })
    .select('id,name,class_code')
    .single();

  if (error) {
    return NextResponse.json(
      { success: false, error: { message: error.message } },
      { status: 500 }
    );
  }

  return NextResponse.json({
    success: true,
    data: {
      id: data.id,
      name: data.name,
      classCode: data.class_code,
    },
  });
}
