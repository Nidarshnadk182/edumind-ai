import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/auth/session';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

export async function POST(request: Request) {
  const session = await getSessionUser();

  if (!session || session.profile.role !== 'teacher') {
    return NextResponse.json(
      { success: false, error: { message: 'Teacher access required.' } },
      { status: 403 }
    );
  }

  const body = await request.json().catch(() => null);
  if (!body?.action) {
    return NextResponse.json(
      { success: false, error: { message: 'Invalid request.' } },
      { status: 400 }
    );
  }

  const supabase = createSupabaseServerClient();
  const { data: teacher } = await supabase
    .from('teacher_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!teacher) {
    return NextResponse.json(
      { success: false, error: { message: 'Complete teacher onboarding first.' } },
      { status: 400 }
    );
  }

  if (body.action === 'mark') {
    const score = Number(body.score);
    const maxScore = Number(body.maxScore);

    if (!body.registerNumber || !body.subject || !body.assessment || !Number.isFinite(score) || !Number.isFinite(maxScore) || maxScore <= 0 || score < 0 || score > maxScore) {
      return NextResponse.json(
        { success: false, error: { message: 'Enter a valid register number, subject, assessment and score.' } },
        { status: 400 }
      );
    }

    const { data: student } = await supabase
      .from('student_profiles')
      .select('id')
      .eq('register_number', String(body.registerNumber).trim())
      .maybeSingle();

    if (!student) {
      return NextResponse.json(
        { success: false, error: { message: 'Student register number not found.' } },
        { status: 404 }
      );
    }

    const { error } = await supabase.from('student_subject_marks').insert({
      student_profile_id: student.id,
      teacher_profile_id: teacher.id,
      subject_name: String(body.subject).trim(),
      assessment_name: String(body.assessment).trim(),
      score,
      max_score: maxScore,
      remarks: body.remarks?.trim() || null,
    });

    if (error) {
      return NextResponse.json({ success: false, error: { message: error.message } }, { status: 500 });
    }
  } else if (body.action === 'resource') {
    if (!body.subject || !body.title || !body.content) {
      return NextResponse.json(
        { success: false, error: { message: 'Subject, title and content are required.' } },
        { status: 400 }
      );
    }

    let targetStudentProfileId: string | null = null;

    if (body.resourceType === 'corrected_paper') {
      if (!body.targetRegisterNumber) {
        return NextResponse.json(
          { success: false, error: { message: 'Enter the student register number for a corrected paper.' } },
          { status: 400 }
        );
      }

      const { data: targetStudent } = await supabase
        .from('student_profiles')
        .select('id')
        .eq('register_number', String(body.targetRegisterNumber).trim())
        .maybeSingle();

      if (!targetStudent) {
        return NextResponse.json(
          { success: false, error: { message: 'Student register number not found.' } },
          { status: 404 }
        );
      }

      targetStudentProfileId = targetStudent.id;
    }

    const { error } = await supabase.from('subject_resources').insert({
      owner_profile_id: session.id,
      target_student_profile_id: targetStudentProfileId,
      subject_name: String(body.subject).trim(),
      chapter_name: body.chapter?.trim() || null,
      title: String(body.title).trim(),
      resource_type: body.resourceType || 'study_material',
      content: String(body.content).trim(),
      visibility: targetStudentProfileId ? 'student' : 'class',
    });

    if (error) {
      return NextResponse.json({ success: false, error: { message: error.message } }, { status: 500 });
    }
  } else if (body.action === 'assignment') {
    if (!body.subject || !body.title || !body.instructions) {
      return NextResponse.json(
        { success: false, error: { message: 'Subject, title and instructions are required.' } },
        { status: 400 }
      );
    }

    const { error } = await supabase.from('teacher_assignments').insert({
      teacher_profile_id: teacher.id,
      subject_name: String(body.subject).trim(),
      chapter_name: body.chapter?.trim() || null,
      title: String(body.title).trim(),
      instructions: String(body.instructions).trim(),
      due_at: body.dueAt || null,
      is_published: true,
    });

    if (error) {
      return NextResponse.json({ success: false, error: { message: error.message } }, { status: 500 });
    }
  } else if (body.action === 'test') {
    const questions = String(body.questions || '')
      .split('\n')
      .map((question) => question.trim())
      .filter(Boolean)
      .map((question, index) => ({ id: index + 1, question }));

    if (!body.subject || !body.title || questions.length === 0) {
      return NextResponse.json(
        { success: false, error: { message: 'Subject, title and at least one question are required.' } },
        { status: 400 }
      );
    }

    const { error } = await supabase.from('teacher_tests').insert({
      teacher_profile_id: teacher.id,
      subject_name: String(body.subject).trim(),
      chapter_name: body.chapter?.trim() || null,
      title: String(body.title).trim(),
      instructions: body.instructions?.trim() || null,
      questions,
      is_published: true,
    });

    if (error) {
      return NextResponse.json({ success: false, error: { message: error.message } }, { status: 500 });
    }
  } else {
    return NextResponse.json(
      { success: false, error: { message: 'Unknown academic action.' } },
      { status: 400 }
    );
  }

  return NextResponse.json({ success: true, data: { saved: true } });
}
