'use client';

import { Suspense, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Brain, Loader2, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  createSupabaseBrowserClient,
  isSupabaseConfigured,
} from '@/lib/database/supabase-browser';

function ForgotPasswordForm() {
  const params = useSearchParams();
  const role = params.get('role') || 'student';
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    if (!isSupabaseConfigured()) {
      setError('Supabase is not configured.');
      return;
    }

    setLoading(true);
    try {
      const supabase = createSupabaseBrowserClient();
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(
        email.trim().toLowerCase(),
        {
          redirectTo: `${window.location.origin}/auth/callback?next=/reset-password`,
        }
      );

      if (resetError) {
        setError(resetError.message);
        return;
      }

      setMessage(
        'If an EduMind account exists for this email, a password-reset link has been sent. Open the email and follow the link.'
      );
    } catch {
      setError('Could not send the password-reset email. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-canvas-light px-6 py-12">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-7 flex items-center justify-center gap-2 font-display font-semibold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600 text-white">
            <Brain className="h-5 w-5" />
          </span>
          EduMind AI
        </Link>

        <section className="card p-7">
          <span className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-50 text-purple-600">
            <Mail className="h-5 w-5" />
          </span>
          <h1 className="font-display text-xl font-semibold">Reset your password</h1>
          <p className="mb-5 mt-2 text-sm leading-6 text-navy-500">
            Enter the Gmail/email address used for your EduMind account. Supabase will send a secure reset link to that address.
          </p>

          {error && <p className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
          {message && <p className="mb-4 rounded-xl bg-green-50 p-3 text-sm text-green-800">{message}</p>}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium">Email address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-navy-200 px-3.5 py-2.5 text-sm"
              />
            </div>
            <Button className="w-full" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Send reset link'}
            </Button>
          </form>

          <Link
            href={`/login?role=${role}`}
            className="mt-5 block text-center text-sm font-medium text-purple-600"
          >
            Back to login
          </Link>
        </section>
      </div>
    </main>
  );
}

export default function ForgotPasswordPage() {
  return (
    <Suspense fallback={<div className="grid min-h-screen place-items-center"><Loader2 className="h-6 w-6 animate-spin" /></div>}>
      <ForgotPasswordForm />
    </Suspense>
  );
}
