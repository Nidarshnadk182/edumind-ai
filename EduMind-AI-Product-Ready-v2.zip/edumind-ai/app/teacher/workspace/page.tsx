'use client';

import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';

type Tab = 'mark' | 'resource' | 'assignment' | 'test';

const TABS: Array<[Tab, string]> = [
  ['mark', 'Enter marks'],
  ['resource', 'Study material / corrected paper'],
  ['assignment', 'Create assignment'],
  ['test', 'Create test'],
];

function Workspace() {
  const params = useSearchParams();
  const initial = params.get('tab') as Tab | null;
  const [tab, setTab] = useState<Tab>(initial && TABS.some(([key]) => key === initial) ? initial : 'mark');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  useEffect(() => {
    const subject = params.get('subject');
    if (subject) {
      setForm((current) => ({ ...current, subject }));
    }
  }, [params]);

  function set(key: string, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage('');

    try {
      const response = await fetch('/api/teacher/workspace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: tab, ...form }),
      });

      const json = await response.json().catch(() => null);
      setMessage(
        response.ok
          ? 'Saved successfully.'
          : json?.error?.message ?? 'Could not save.'
      );

      if (response.ok) {
        const subject = form.subject;
        setForm(subject ? { subject } : {});
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Academic workspace</h1>
        <p className="text-sm text-navy-500">
          Enter real student marks, add learning material, create assignments and publish tests.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map(([key, label]) => (
          <button
            key={key}
            onClick={() => {
              setTab(key);
              setMessage('');
              const subject = form.subject;
              setForm(subject ? { subject } : {});
            }}
            className={`rounded-full px-4 py-2 text-sm ${
              tab === key ? 'bg-purple-600 text-white' : 'border bg-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <section className="card max-w-2xl p-6">
        {message && (
          <p className="mb-4 rounded-xl bg-purple-50 p-3 text-sm">{message}</p>
        )}

        <form onSubmit={save} className="space-y-4">
          {tab === 'mark' && (
            <>
              <Field label="Student register number" keyName="registerNumber" form={form} set={set} />
              <Field label="Subject" keyName="subject" form={form} set={set} />
              <Field label="Assessment name (e.g. Mid Sem 1)" keyName="assessment" form={form} set={set} />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Score" keyName="score" form={form} set={set} type="number" />
                <Field label="Maximum score" keyName="maxScore" form={form} set={set} type="number" />
              </div>
              <Field label="Remarks" keyName="remarks" form={form} set={set} required={false} />
            </>
          )}

          {tab === 'resource' && (
            <>
              <Field label="Subject" keyName="subject" form={form} set={set} />
              <Field label="Chapter" keyName="chapter" form={form} set={set} required={false} />
              <Field label="Title" keyName="title" form={form} set={set} />
              <label className="block text-sm">
                <span className="mb-1 block font-medium">Type</span>
                <select
                  value={form.resourceType || 'study_material'}
                  onChange={(e) => set('resourceType', e.target.value)}
                  className="w-full rounded-xl border p-2.5"
                >
                  <option value="study_material">Study material</option>
                  <option value="corrected_paper">Corrected paper / feedback</option>
                  <option value="notes">Notes</option>
                </select>
              </label>
              {form.resourceType === 'corrected_paper' && (
                <Field
                  label="Student register number (for this corrected paper)"
                  keyName="targetRegisterNumber"
                  form={form}
                  set={set}
                />
              )}
              <TextArea
                label="Material / feedback / corrected-paper text"
                keyName="content"
                form={form}
                set={set}
              />
            </>
          )}

          {tab === 'assignment' && (
            <>
              <Field label="Subject" keyName="subject" form={form} set={set} />
              <Field label="Chapter" keyName="chapter" form={form} set={set} required={false} />
              <Field label="Assignment title" keyName="title" form={form} set={set} />
              <TextArea label="Assignment instructions" keyName="instructions" form={form} set={set} />
              <Field label="Due date" keyName="dueAt" form={form} set={set} type="datetime-local" required={false} />
            </>
          )}

          {tab === 'test' && (
            <>
              <Field label="Subject" keyName="subject" form={form} set={set} />
              <Field label="Chapter" keyName="chapter" form={form} set={set} required={false} />
              <Field label="Test title" keyName="title" form={form} set={set} />
              <TextArea label="Instructions" keyName="instructions" form={form} set={set} required={false} />
              <TextArea label="Questions (one question per line)" keyName="questions" form={form} set={set} />
            </>
          )}

          <Button disabled={busy}>{busy ? 'Saving...' : 'Save'}</Button>
        </form>
      </section>

      <p className="text-xs text-navy-400">
        This page saves information to Supabase. It no longer uses sample student names or sample marks.
      </p>
    </div>
  );
}

export default function TeacherWorkspacePage() {
  return (
    <Suspense fallback={<div className="text-sm text-navy-500">Loading workspace...</div>}>
      <Workspace />
    </Suspense>
  );
}

function Field({
  label,
  keyName,
  form,
  set,
  required = true,
  type = 'text',
}: {
  label: string;
  keyName: string;
  form: Record<string, string>;
  set: (key: string, value: string) => void;
  required?: boolean;
  type?: string;
}) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      <input
        required={required}
        type={type}
        value={form[keyName] || ''}
        onChange={(e) => set(keyName, e.target.value)}
        className="w-full rounded-xl border p-2.5"
      />
    </label>
  );
}

function TextArea({
  label,
  keyName,
  form,
  set,
  required = true,
}: {
  label: string;
  keyName: string;
  form: Record<string, string>;
  set: (key: string, value: string) => void;
  required?: boolean;
}) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      <textarea
        rows={5}
        required={required}
        value={form[keyName] || ''}
        onChange={(e) => set(keyName, e.target.value)}
        className="w-full rounded-xl border p-2.5"
      />
    </label>
  );
}
