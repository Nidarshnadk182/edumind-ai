'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Users, Plus, Upload, Loader2, X } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface TeacherClass {
  id: string;
  name: string;
  classCode: string;
  subjectName: string;
  students: number;
  academicYear?: string | null;
  academicTerm?: string | null;
  programme?: string | null;
  sectionName?: string | null;
}

export default function TeacherClassesPage() {
  const [classes, setClasses] = useState<TeacherClass[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '',
    subjectName: '',
    programme: '',
    sectionName: '',
    academicYear: '',
    academicTerm: '',
  });

  async function loadClasses() {
    setLoading(true);
    setError(null);

    const response = await fetch('/api/classes/create', { cache: 'no-store' });
    const json = await response.json().catch(() => null);

    if (!response.ok) {
      setError(json?.error?.message ?? 'Could not load classes.');
      setLoading(false);
      return;
    }

    setClasses(json?.data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    void loadClasses();
  }, []);

  async function createClass(event: React.FormEvent) {
    event.preventDefault();
    setCreating(true);
    setError(null);

    try {
      const response = await fetch('/api/classes/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const json = await response.json().catch(() => null);

      if (!response.ok) {
        setError(json?.error?.message ?? 'Could not create class.');
        return;
      }

      setForm({
        name: '',
        subjectName: '',
        programme: '',
        sectionName: '',
        academicYear: '',
        academicTerm: '',
      });
      setShowCreate(false);
      await loadClasses();
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 font-display text-2xl font-semibold text-navy-900 dark:text-lavender-50">
            <Users className="h-6 w-6 text-purple-600" /> Classes
          </h1>
          <p className="text-sm text-navy-500">Create and manage as many classes as you teach.</p>
        </div>
        <Button onClick={() => setShowCreate((value) => !value)}>
          {showCreate ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
          {showCreate ? 'Close' : 'Create class'}
        </Button>
      </div>

      {error && <div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</div>}

      {showCreate && (
        <Card>
          <CardTitle>Create a new class</CardTitle>
          <CardDescription>
            Each class gets its own join code. Students can use that code to join.
          </CardDescription>

          <form onSubmit={createClass} className="mt-5 grid gap-4 md:grid-cols-2">
            <Input label="Class name" value={form.name} onChange={(value) => setForm({ ...form, name: value })} required />
            <Input label="Subject" value={form.subjectName} onChange={(value) => setForm({ ...form, subjectName: value })} required />
            <Input label="Programme / standard" value={form.programme} onChange={(value) => setForm({ ...form, programme: value })} />
            <Input label="Section" value={form.sectionName} onChange={(value) => setForm({ ...form, sectionName: value })} />
            <Input label="Academic year" value={form.academicYear} onChange={(value) => setForm({ ...form, academicYear: value })} />
            <Input label="Term / semester" value={form.academicTerm} onChange={(value) => setForm({ ...form, academicTerm: value })} />

            <div className="md:col-span-2">
              <Button disabled={creating}>
                {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                Create class
              </Button>
            </div>
          </form>
        </Card>
      )}

      {loading ? (
        <div className="flex items-center gap-2 text-sm text-navy-500">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading classes...
        </div>
      ) : classes.length === 0 ? (
        <Card>
          <CardTitle>No classes yet</CardTitle>
          <CardDescription>
            Create your first class. No sample or fake classes are shown.
          </CardDescription>
        </Card>
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {classes.map((item) => (
            <Card key={item.id}>
              <CardTitle>{item.name}</CardTitle>
              <CardDescription>{item.subjectName}</CardDescription>

              {(item.programme || item.sectionName) && (
                <p className="mt-2 text-xs text-navy-500">
                  {[item.programme, item.sectionName].filter(Boolean).join(' · ')}
                </p>
              )}

              <div className="mt-4 flex items-center justify-between">
                <div>
                  <p className="text-xs text-navy-400">Class code</p>
                  <p className="font-mono text-sm font-semibold text-purple-600">{item.classCode}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-navy-400">Students</p>
                  <p className="text-sm font-semibold">{item.students}</p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <Link
                  href={`/teacher/workspace?tab=resource&subject=${encodeURIComponent(item.subjectName)}`}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-navy-200 px-3 py-2 text-sm font-medium"
                >
                  <Upload className="h-3.5 w-3.5" /> Material
                </Link>
                <Link
                  href={`/teacher/workspace?tab=assignment&subject=${encodeURIComponent(item.subjectName)}`}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-purple-600 px-3 py-2 text-sm font-medium text-white"
                >
                  <Plus className="h-3.5 w-3.5" /> Assignment
                </Link>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  required = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      <input
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-navy-200 px-3 py-2.5"
      />
    </label>
  );
}
