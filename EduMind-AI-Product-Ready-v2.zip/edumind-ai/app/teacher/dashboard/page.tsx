import Link from 'next/link';
import { Users, TrendingUp, Plus, School, ClipboardList } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient } from '@/lib/database/supabase-server';

export default async function TeacherDashboardPage() {
  const session = await requireRole(['teacher']);
  const supabase = createSupabaseServerClient();

  const { data: teacher } = await supabase
    .from('teacher_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  let classes: Array<any> = [];
  let studentCount = 0;
  let averageScore: number | null = null;
  let assignmentCount = 0;

  if (teacher) {
    const { data: classRows } = await supabase
      .from('classes')
      .select('id,name,class_code,subjects(name)')
      .eq('teacher_id', teacher.id)
      .is('archived_at', null)
      .order('created_at', { ascending: false });

    classes = classRows ?? [];
    const classIds = classes.map((item) => item.id);

    if (classIds.length) {
      const { data: members } = await supabase
        .from('class_members')
        .select('student_id')
        .in('class_id', classIds);

      studentCount = new Set((members ?? []).map((item: any) => item.student_id)).size;
    }

    const { data: marks } = await supabase
      .from('student_subject_marks')
      .select('score,max_score')
      .eq('teacher_profile_id', teacher.id);

    const percentages = (marks ?? [])
      .filter((item: any) => Number(item.max_score) > 0)
      .map((item: any) => (Number(item.score) / Number(item.max_score)) * 100);

    if (percentages.length) {
      averageScore = Math.round(
        percentages.reduce((sum: number, value: number) => sum + value, 0) / percentages.length
      );
    }

    const { count } = await supabase
      .from('teacher_assignments')
      .select('id', { count: 'exact', head: true })
      .eq('teacher_profile_id', teacher.id);

    assignmentCount = count ?? 0;
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-sm text-navy-500">Welcome,</p>
          <h1 className="font-display text-2xl font-semibold text-navy-900">
            {session.profile.full_name}
          </h1>
          <p className="text-sm text-navy-500">Teacher Dashboard</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            href="/teacher/classes"
            className="inline-flex items-center gap-2 rounded-xl border border-navy-200 px-4 py-2 text-sm font-medium"
          >
            <Plus className="h-4 w-4" /> Create class
          </Link>
          <Link
            href="/teacher/workspace?tab=assignment"
            className="inline-flex items-center gap-2 rounded-xl bg-purple-600 px-4 py-2 text-sm font-medium text-white"
          >
            <ClipboardList className="h-4 w-4" /> Create assignment
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Your classes" value={String(classes.length)} icon={School} />
        <StatCard label="Students in classes" value={String(studentCount)} icon={Users} />
        <StatCard label="Average marks entered" value={averageScore === null ? '—' : `${averageScore}%`} icon={TrendingUp} />
        <StatCard label="Assignments created" value={String(assignmentCount)} icon={ClipboardList} />
      </div>

      <Card>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Your classes</CardTitle>
            <CardDescription>Only classes created by your account are shown.</CardDescription>
          </div>
          <Link href="/teacher/classes" className="text-sm font-medium text-purple-600">
            Manage classes
          </Link>
        </div>

        {classes.length === 0 ? (
          <div className="mt-5 rounded-xl border border-dashed border-navy-200 p-6 text-sm text-navy-500">
            No classes have been created yet. Use <strong>Create class</strong> to add your first class.
          </div>
        ) : (
          <div className="mt-4 divide-y divide-navy-100">
            {classes.slice(0, 6).map((item: any) => (
              <div key={item.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium text-navy-900">{item.name}</p>
                  <p className="text-xs text-navy-500">{item.subjects?.name ?? 'Subject'}</p>
                </div>
                <span className="font-mono text-xs font-semibold text-purple-600">{item.class_code}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card>
        <CardTitle>Academic actions</CardTitle>
        <CardDescription>
          All information entered here is stored in Supabase; no sample student names or marks are inserted automatically.
        </CardDescription>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Quick href="/teacher/workspace?tab=mark" label="Enter student marks" />
          <Quick href="/teacher/workspace?tab=resource" label="Add study material" />
          <Quick href="/teacher/workspace?tab=assignment" label="Create assignment" />
          <Quick href="/teacher/workspace?tab=test" label="Create test" />
        </div>
      </Card>
    </div>
  );
}

function StatCard({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Users }) {
  return (
    <Card className="!p-5">
      <span className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
        <Icon className="h-4.5 w-4.5" />
      </span>
      <p className="font-display text-xl font-semibold">{value}</p>
      <p className="text-xs text-navy-500">{label}</p>
    </Card>
  );
}

function Quick({ href, label }: { href: string; label: string }) {
  return (
    <Link
      href={href}
      className="rounded-xl border border-navy-200 px-4 py-3 text-center text-sm font-medium hover:border-purple-300 hover:text-purple-700"
    >
      {label}
    </Link>
  );
}
