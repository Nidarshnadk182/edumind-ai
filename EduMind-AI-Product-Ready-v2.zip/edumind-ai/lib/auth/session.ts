import 'server-only';
import { redirect } from 'next/navigation';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { Profile, UserRole } from '@/types/database';

export interface SessionUser {
  id: string;
  email: string | null;
  profile: Profile;
}

export async function getSessionUser(): Promise<SessionUser | null> {
  if (!isSupabaseConfigured()) return null;

  const supabase = createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle();

  if (!profile) return null;

  return {
    id: user.id,
    email: user.email ?? null,
    profile: profile as Profile,
  };
}

export async function requireSession(): Promise<SessionUser> {
  const session = await getSessionUser();
  if (!session) redirect('/');
  return session;
}

export async function requireRole(allowedRoles: UserRole[]): Promise<SessionUser> {
  const session = await requireSession();

  if (!session.profile.onboarding_completed) {
    redirect('/onboarding');
  }

  if (!allowedRoles.includes(session.profile.role)) {
    redirect(`/${session.profile.role}/dashboard`);
  }

  return session;
}
