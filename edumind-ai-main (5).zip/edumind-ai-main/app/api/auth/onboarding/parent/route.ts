import { NextResponse } from 'next/server';
import { parentOnboardingSchema } from '@/lib/validations/schemas';
import { getSessionUser } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

export async function POST(request: Request) {
  const session = await getSessionUser();
  if (!session) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Not authenticated', code: 'UNAUTHENTICATED' } },
      { status: 401 }
    );
  }

  const body = await request.json().catch(() => null);
  const parsed = parentOnboardingSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Invalid onboarding data', code: 'VALIDATION_ERROR' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data } = parsed;

  // Find the child by register number.
  const { data: child, error: childLookupError } = await supabase
    .from('student_profiles')
    .select('id, profile_id')
    .eq('register_number', data.childRegisterNumber.trim())
    .maybeSingle();

  if (childLookupError) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not look up the student. Please try again.' } },
      { status: 500 }
    );
  }

  if (!child) {
    return NextResponse.json<ApiResponse<never>>(
      {
        success: false,
        error: {
          message:
            'No student was found with that register number. Double-check it with your child or their school, then try again — you can add this later from your dashboard.',
          code: 'CHILD_NOT_FOUND',
        },
      },
      { status: 404 }
    );
  }

  const { error: parentProfileError } = await supabase.from('parent_profiles').upsert(
    {
      profile_id: session.id,
      contact_number: data.contactNumber,
    },
    { onConflict: 'profile_id' }
  );

  if (parentProfileError) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not save your profile' } },
      { status: 500 }
    );
  }

  const { error: linkError } = await supabase.from('parent_student_links').upsert(
    {
      parent_profile_id: session.id,
      student_profile_id: child.profile_id,
      consent_confirmed: true,
    },
    { onConflict: 'parent_profile_id,student_profile_id' }
  );

  if (linkError) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not link your child\u2019s account' } },
      { status: 500 }
    );
  }

  await supabase
    .from('profiles')
    .update({ full_name: data.fullName, role: 'parent', onboarding_completed: true, updated_at: new Date().toISOString() })
    .eq('id', session.id);

  return NextResponse.json<ApiResponse<{ saved: true }>>({ success: true, data: { saved: true } });
}
