import { NextResponse } from 'next/server';
import { institutionOnboardingSchema } from '@/lib/validations/schemas';
import { getSessionUser } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

export async function POST(request: Request) {
  const session = await getSessionUser();
  if (!session) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Not authenticated', code: 'UNAUTHENTICATED' } },
      { status: 401 }
    );
  }

  const body = await request.json().catch(() => null);
  const parsed = institutionOnboardingSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Invalid onboarding data', code: 'VALIDATION_ERROR' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data } = parsed;

  const { error } = await supabase.from('institutions').upsert(
    {
      admin_profile_id: session.id,
      name: data.institutionName,
      contact_email: data.contactEmail,
    },
    { onConflict: 'admin_profile_id' }
  );

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not save your institution' } },
      { status: 500 }
    );
  }

  await supabase
    .from('profiles')
    .update({ full_name: data.fullName, role: 'institution', onboarding_completed: true, updated_at: new Date().toISOString() })
    .eq('id', session.id);

  return NextResponse.json<ApiResponse<{ saved: true }>>({ success: true, data: { saved: true } });
}
