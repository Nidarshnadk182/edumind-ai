import { NextResponse } from 'next/server';
import { subjectContentUploadSchema } from '@/lib/validations/schemas';
import { getSessionUser } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

// GET /api/materials?subject=...&contentType=material|test&mine=1
export async function GET(request: Request) {
  const session = await getSessionUser();
  if (!session) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Not authenticated' } },
      { status: 401 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ items: [] }>>({ success: true, data: { items: [] } });
  }

  const supabase = createSupabaseServerClient();
  const { searchParams } = new URL(request.url);
  const subject = searchParams.get('subject');
  const contentType = searchParams.get('contentType');
  const mine = searchParams.get('mine');

  let query = supabase.from('subject_content').select('*').order('created_at', { ascending: false });

  if (subject) query = query.eq('subject', subject);
  if (contentType) query = query.eq('content_type', contentType);
  if (mine) query = query.eq('owner_profile_id', session.id);

  const { data, error } = await query;

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not load materials' } },
      { status: 500 }
    );
  }

  return NextResponse.json<ApiResponse<{ items: typeof data }>>({ success: true, data: { items: data } });
}

export async function POST(request: Request) {
  const session = await getSessionUser();
  if (!session) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Not authenticated' } },
      { status: 401 }
    );
  }

  if (!['teacher', 'student'].includes(session.profile.role)) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Only teachers and students can add subject content' } },
      { status: 403 }
    );
  }

  const body = await request.json().catch(() => null);
  const parsed = subjectContentUploadSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Invalid content data', code: 'VALIDATION_ERROR' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data } = parsed;

  // Students may only add their own private study material, never tests,
  // and it is never shown to other students.
  const isStudent = session.profile.role === 'student';
  if (isStudent && data.contentType === 'test') {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Only teachers can upload tests' } },
      { status: 403 }
    );
  }

  const { error } = await supabase.from('subject_content').insert({
    owner_profile_id: session.id,
    subject: data.subject,
    content_type: data.contentType,
    title: data.title,
    body_text: data.bodyText,
    class_id: data.classId ?? null,
    visible_to_students: isStudent ? false : true,
  });

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not save content' } },
      { status: 500 }
    );
  }

  return NextResponse.json<ApiResponse<{ saved: true }>>({ success: true, data: { saved: true } });
}
