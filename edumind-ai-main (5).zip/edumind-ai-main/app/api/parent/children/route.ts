import { NextResponse } from 'next/server';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import { predictPerformance } from '@/lib/prediction/engine';
import type { ApiResponse } from '@/types/database';

export async function GET() {
  const session = await requireRole(['parent']);

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ children: [] }>>({ success: true, data: { children: [] } });
  }

  const supabase = createSupabaseServerClient();

  const { data: links } = await supabase
    .from('parent_student_links')
    .select('student_profile_id, consent_confirmed')
    .eq('parent_profile_id', session.id)
    .eq('consent_confirmed', true);

  if (!links || links.length === 0) {
    return NextResponse.json<ApiResponse<{ children: [] }>>({ success: true, data: { children: [] } });
  }

  const children = await Promise.all(
    links.map(async (link) => {
      const { data: studentProfile } = await supabase
        .from('student_profiles')
        .select('id, register_number, standard, section, profiles(full_name)')
        .eq('profile_id', link.student_profile_id)
        .maybeSingle();

      if (!studentProfile) return null;

      const { data: marks } = await supabase
        .from('teacher_subject_marks')
        .select('subject, exam_name, marks_obtained, marks_total, exam_date')
        .eq('student_id', studentProfile.id)
        .order('exam_date', { ascending: false })
        .limit(20);

      const { data: progress } = await supabase
        .from('learning_progress')
        .select('mastery_score')
        .eq('student_id', studentProfile.id);

      const scores = (marks ?? []).map((m) => (m.marks_obtained / m.marks_total) * 100);
      const quizAverage = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
      const masteryScores = (progress ?? []).map((p) => Number(p.mastery_score ?? 0));
      const masteryAverage = masteryScores.length ? masteryScores.reduce((a, b) => a + b, 0) / masteryScores.length : quizAverage;

      const hasEnoughData = scores.length >= 2;

      const prediction = hasEnoughData
        ? predictPerformance({
            quizAverage,
            masteryAverage,
            completionRate: 70,
            revisionConsistency: 65,
          })
        : null;

      const profile = Array.isArray(studentProfile.profiles) ? studentProfile.profiles[0] : studentProfile.profiles;

      return {
        id: studentProfile.id,
        fullName: profile?.full_name ?? 'Student',
        registerNumber: studentProfile.register_number,
        standard: studentProfile.standard,
        section: studentProfile.section,
        marks: marks ?? [],
        avgScore: Math.round(quizAverage),
        prediction,
      };
    })
  );

  return NextResponse.json<ApiResponse<{ children: typeof children }>>({
    success: true,
    data: { children: children.filter(Boolean) },
  });
}
