import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

const linkChildSchema = z.object({
  registerNumber: z.string().min(1).max(50),
});

export async function POST(request: Request) {
  const session = await requireRole(['parent']);

  const body = await request.json().catch(() => null);
  const parsed = linkChildSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Please enter a register number.' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();

  const { data: child } = await supabase
    .from('student_profiles')
    .select('id, profile_id')
    .eq('register_number', parsed.data.registerNumber.trim())
    .maybeSingle();

  if (!child) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'No student found with that register number.' } },
      { status: 404 }
    );
  }

  const { error } = await supabase.from('parent_student_links').upsert(
    { parent_profile_id: session.id, student_profile_id: child.profile_id, consent_confirmed: true },
    { onConflict: 'parent_profile_id,student_profile_id' }
  );

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not link the student.' } },
      { status: 500 }
    );
  }

  return NextResponse.json<ApiResponse<{ linked: true }>>({ success: true, data: { linked: true } });
}
