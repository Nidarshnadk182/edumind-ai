import { NextResponse } from 'next/server';
import { studentDifficultySchema } from '@/lib/validations/schemas';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

export async function GET() {
  const session = await requireRole(['student']);

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ items: [] }>>({ success: true, data: { items: [] } });
  }

  const supabase = createSupabaseServerClient();
  const { data: studentProfile } = await supabase
    .from('student_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!studentProfile) {
    return NextResponse.json<ApiResponse<{ items: [] }>>({ success: true, data: { items: [] } });
  }

  const { data, error } = await supabase
    .from('student_topic_difficulty')
    .select('*')
    .eq('student_id', studentProfile.id)
    .order('updated_at', { ascending: false });

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not load difficulty tags' } },
      { status: 500 }
    );
  }

  return NextResponse.json<ApiResponse<{ items: typeof data }>>({ success: true, data: { items: data } });
}

export async function POST(request: Request) {
  const session = await requireRole(['student']);

  const body = await request.json().catch(() => null);
  const parsed = studentDifficultySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Invalid difficulty tag', code: 'VALIDATION_ERROR' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data: studentProfile } = await supabase
    .from('student_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!studentProfile) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Student profile not found' } },
      { status: 404 }
    );
  }

  const { data } = parsed;

  const { error } = await supabase.from('student_topic_difficulty').insert({
    student_id: studentProfile.id,
    subject: data.subject,
    topic: data.topic,
    difficulty_level: data.difficultyLevel,
    note: data.note,
  });

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not save difficulty tag' } },
      { status: 500 }
    );
  }

  // This is read by the AI Tutor (as context on what the student
  // struggles with) and by the recommendation engine as a priority
  // signal alongside quiz score, mastery and doubts count.
  return NextResponse.json<ApiResponse<{ saved: true }>>({ success: true, data: { saved: true } });
}
