import { NextResponse } from 'next/server';
import { teacherMarkEntrySchema } from '@/lib/validations/schemas';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

// GET /api/teacher/marks?studentId=... — marks history for one student
// GET /api/teacher/marks — all marks this teacher has entered
export async function GET(request: Request) {
  const session = await requireRole(['teacher']);

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ marks: [] }>>({ success: true, data: { marks: [] } });
  }

  const supabase = createSupabaseServerClient();
  const { data: teacherProfile } = await supabase
    .from('teacher_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!teacherProfile) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Teacher profile not found' } },
      { status: 404 }
    );
  }

  const { searchParams } = new URL(request.url);
  const studentId = searchParams.get('studentId');

  let query = supabase
    .from('teacher_subject_marks')
    .select('*')
    .eq('teacher_id', teacherProfile.id)
    .order('exam_date', { ascending: false });

  if (studentId) {
    query = query.eq('student_id', studentId);
  }

  const { data, error } = await query;

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not load marks' } },
      { status: 500 }
    );
  }

  return NextResponse.json<ApiResponse<{ marks: typeof data }>>({ success: true, data: { marks: data } });
}

export async function POST(request: Request) {
  const session = await requireRole(['teacher']);

  const body = await request.json().catch(() => null);
  const parsed = teacherMarkEntrySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Invalid marks data', code: 'VALIDATION_ERROR' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data: teacherProfile } = await supabase
    .from('teacher_profiles')
    .select('id')
    .eq('profile_id', session.id)
    .maybeSingle();

  if (!teacherProfile) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Teacher profile not found' } },
      { status: 404 }
    );
  }

  const { data } = parsed;

  const { error } = await supabase.from('teacher_subject_marks').insert({
    teacher_id: teacherProfile.id,
    student_id: data.studentId,
    subject: data.subject,
    exam_name: data.examName,
    marks_obtained: data.marksObtained,
    marks_total: data.marksTotal,
    exam_date: data.examDate ?? new Date().toISOString().slice(0, 10),
    notes: data.notes,
  });

  if (error) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Could not save marks' } },
      { status: 500 }
    );
  }

  return NextResponse.json<ApiResponse<{ saved: true }>>({ success: true, data: { saved: true } });
}
