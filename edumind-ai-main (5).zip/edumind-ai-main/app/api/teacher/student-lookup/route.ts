import { NextResponse } from 'next/server';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

export async function GET(request: Request) {
  await requireRole(['teacher']);

  const { searchParams } = new URL(request.url);
  const registerNumber = searchParams.get('registerNumber')?.trim();

  if (!registerNumber) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Provide a register number' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Student lookup requires a configured database.' } },
      { status: 503 }
    );
  }

  const supabase = createSupabaseServerClient();

  const { data: student } = await supabase
    .from('student_profiles')
    .select('id, register_number, standard, section, profile_id, profiles(full_name)')
    .eq('register_number', registerNumber)
    .maybeSingle();

  if (!student) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'No student found with that register number.' } },
      { status: 404 }
    );
  }

  return NextResponse.json<ApiResponse<{ student: typeof student }>>({ success: true, data: { student } });
}
