import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireRole } from '@/lib/auth/session';
import { createSupabaseServerClient, isSupabaseConfigured } from '@/lib/database/supabase-server';
import type { ApiResponse } from '@/types/database';

export async function GET() {
  const session = await requireRole(['institution']);

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ teachers: []; students: [] }>>({
      success: true,
      data: { teachers: [], students: [] },
    });
  }

  const supabase = createSupabaseServerClient();

  const { data: institution } = await supabase
    .from('institutions')
    .select('id')
    .eq('admin_profile_id', session.id)
    .maybeSingle();

  if (!institution) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'No institution found for this admin account.' } },
      { status: 404 }
    );
  }

  const [{ data: teachers }, { data: students }] = await Promise.all([
    supabase
      .from('teacher_profiles')
      .select('id, subjects_taught, grade_or_class, profiles(full_name)')
      .eq('institution_id', institution.id),
    supabase
      .from('student_profiles')
      .select('id, register_number, standard, section, profiles(full_name)')
      .eq('institution_id', institution.id),
  ]);

  return NextResponse.json<ApiResponse<{ teachers: typeof teachers; students: typeof students }>>({
    success: true,
    data: { teachers: teachers ?? [], students: students ?? [] },
  });
}

const addUserSchema = z.object({
  kind: z.enum(['teacher', 'student']),
  identifier: z.string().min(1).max(50), // email for teachers, register number for students
});

export async function POST(request: Request) {
  const session = await requireRole(['institution']);

  const body = await request.json().catch(() => null);
  const parsed = addUserSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'Provide the register number (student) or email (teacher).' } },
      { status: 400 }
    );
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data: institution } = await supabase
    .from('institutions')
    .select('id')
    .eq('admin_profile_id', session.id)
    .maybeSingle();

  if (!institution) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { message: 'No institution found for this admin account.' } },
      { status: 404 }
    );
  }

  if (parsed.data.kind === 'student') {
    const { error } = await supabase
      .from('student_profiles')
      .update({ institution_id: institution.id })
      .eq('register_number', parsed.data.identifier.trim());

    if (error) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { message: 'Could not find or add that student.' } },
        { status: 404 }
      );
    }
  } else {
    // Institution admins add teachers using the teacher's account ID,
    // which each teacher can see on their own dashboard. (Matching by
    // email would require the Supabase service-role admin API, which
    // is intentionally not exposed to this route.)
    const { error } = await supabase
      .from('teacher_profiles')
      .update({ institution_id: institution.id, added_by_institution_id: institution.id })
      .eq('profile_id', parsed.data.identifier.trim());

    if (error) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { message: 'Could not find or add that teacher.' } },
        { status: 404 }
      );
    }
  }

  return NextResponse.json<ApiResponse<{ added: true }>>({ success: true, data: { added: true } });
}

export async function DELETE(request: Request) {
  const session = await requireRole(['institution']);
  const { searchParams } = new URL(request.url);
  const kind = searchParams.get('kind');
  const id = searchParams.get('id');

  if (!kind || !id || !['teacher', 'student'].includes(kind)) {
    return NextResponse.json<ApiResponse<never>>({ success: false, error: { message: 'Invalid request' } }, { status: 400 });
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json<ApiResponse<{ demo: true }>>({ success: true, data: { demo: true } });
  }

  const supabase = createSupabaseServerClient();
  const { data: institution } = await supabase
    .from('institutions')
    .select('id')
    .eq('admin_profile_id', session.id)
    .maybeSingle();

  if (!institution) {
    return NextResponse.json<ApiResponse<never>>({ success: false, error: { message: 'No institution found.' } }, { status: 404 });
  }

  const table = kind === 'teacher' ? 'teacher_profiles' : 'student_profiles';
  const { error } = await supabase
    .from(table)
    .update({ institution_id: null })
    .eq('id', id)
    .eq('institution_id', institution.id);

  if (error) {
    return NextResponse.json<ApiResponse<never>>({ success: false, error: { message: 'Could not remove user.' } }, { status: 500 });
  }

  return NextResponse.json<ApiResponse<{ removed: true }>>({ success: true, data: { removed: true } });
}
