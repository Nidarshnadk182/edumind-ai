'use client';

import { useEffect, useState } from 'react';
import { Users, UserPlus, Trash2, Loader2, GraduationCap, School } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface Teacher {
  id: string;
  subjects_taught: string[];
  grade_or_class: string | null;
  profiles: { full_name: string } | { full_name: string }[] | null;
}

interface Student {
  id: string;
  register_number: string;
  standard: string | null;
  section: string | null;
  profiles: { full_name: string } | { full_name: string }[] | null;
}

function name(p: Teacher['profiles'] | Student['profiles']): string {
  const profile = Array.isArray(p) ? p[0] : p;
  return profile?.full_name ?? 'Unnamed';
}

export default function InstitutionUsersPage() {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [addKind, setAddKind] = useState<'student' | 'teacher'>('student');
  const [identifier, setIdentifier] = useState('');
  const [adding, setAdding] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch('/api/institution/users');
      const json = await res.json().catch(() => null);
      if (res.ok && json?.success) {
        setTeachers(json.data.teachers);
        setStudents(json.data.students);
      } else {
        setError(json?.error?.message ?? 'Could not load users.');
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setAdding(true);
    try {
      const res = await fetch('/api/institution/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: addKind, identifier: identifier.trim() }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setError(json?.error?.message ?? 'Could not add that user.');
        return;
      }
      setIdentifier('');
      await load();
    } catch {
      setError('Something went wrong.');
    } finally {
      setAdding(false);
    }
  }

  async function handleRemove(kind: 'teacher' | 'student', id: string) {
    await fetch(`/api/institution/users?kind=${kind}&id=${id}`, { method: 'DELETE' });
    await load();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy-900 dark:text-lavender-50 flex items-center gap-2">
          <Users className="h-6 w-6 text-purple-600 dark:text-purple-300" /> Manage Users
        </h1>
        <p className="text-sm text-navy-500 dark:text-lavender-400">Add or remove teachers and students from your institution.</p>
      </div>

      <Card>
        <CardTitle className="!text-base flex items-center gap-2">
          <UserPlus className="h-4 w-4 text-purple-600" /> Add a user
        </CardTitle>
        <form onSubmit={handleAdd} className="mt-3 flex flex-wrap items-end gap-3">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setAddKind('student')}
              className={cn(
                'rounded-xl border px-3 py-2 text-sm font-medium',
                addKind === 'student' ? 'border-purple-400 bg-purple-50 text-purple-700' : 'border-navy-200 text-navy-600'
              )}
            >
              Student
            </button>
            <button
              type="button"
              onClick={() => setAddKind('teacher')}
              className={cn(
                'rounded-xl border px-3 py-2 text-sm font-medium',
                addKind === 'teacher' ? 'border-purple-400 bg-purple-50 text-purple-700' : 'border-navy-200 text-navy-600'
              )}
            >
              Teacher
            </button>
          </div>
          <div className="flex-1 min-w-[220px]">
            <input
              required
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder={addKind === 'student' ? "Student's register number" : "Teacher's account ID (from their dashboard)"}
              className="w-full rounded-xl border border-navy-200 dark:border-navy-700 bg-white dark:bg-navy-900 px-3.5 py-2.5 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-200"
            />
          </div>
          <Button type="submit" disabled={adding}>
            {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Add'}
          </Button>
        </form>
        {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
      </Card>

      {loading ? (
        <div className="flex items-center gap-2 text-navy-400">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading...
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardTitle className="!text-base flex items-center gap-2">
              <School className="h-4 w-4 text-purple-600" /> Teachers ({teachers.length})
            </CardTitle>
            <div className="mt-3 space-y-2 max-h-[28rem] overflow-y-auto">
              {teachers.length === 0 && <p className="text-sm text-navy-400 dark:text-lavender-500">No teachers added yet.</p>}
              {teachers.map((t) => (
                <div key={t.id} className="flex items-center justify-between rounded-xl border border-navy-100 dark:border-navy-800 p-3">
                  <div>
                    <p className="text-sm font-medium text-navy-800 dark:text-lavender-100">{name(t.profiles)}</p>
                    <p className="text-xs text-navy-400 dark:text-lavender-500">{t.subjects_taught?.join(', ') || '—'}</p>
                  </div>
                  <button onClick={() => handleRemove('teacher', t.id)} className="text-navy-400 hover:text-red-500">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <CardTitle className="!text-base flex items-center gap-2">
              <GraduationCap className="h-4 w-4 text-purple-600" /> Students ({students.length})
            </CardTitle>
            <div className="mt-3 space-y-2 max-h-[28rem] overflow-y-auto">
              {students.length === 0 && <p className="text-sm text-navy-400 dark:text-lavender-500">No students added yet.</p>}
              {students.map((s) => (
                <div key={s.id} className="flex items-center justify-between rounded-xl border border-navy-100 dark:border-navy-800 p-3">
                  <div>
                    <p className="text-sm font-medium text-navy-800 dark:text-lavender-100">{name(s.profiles)}</p>
                    <p className="text-xs text-navy-400 dark:text-lavender-500">
                      {s.register_number} · {s.standard ?? '—'} {s.section ?? ''}
                    </p>
                  </div>
                  <button onClick={() => handleRemove('student', s.id)} className="text-navy-400 hover:text-red-500">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
