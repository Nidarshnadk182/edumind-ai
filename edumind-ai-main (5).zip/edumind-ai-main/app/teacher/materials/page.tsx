'use client';

import { useEffect, useState } from 'react';
import { Upload, FileText, ClipboardList, Loader2, CheckCircle2 } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ContentItem {
  id: string;
  subject: string;
  content_type: 'material' | 'test';
  title: string;
  body_text: string;
  created_at: string;
}

export default function TeacherMaterialsPage() {
  const [items, setItems] = useState<ContentItem[]>([]);
  const [loadingItems, setLoadingItems] = useState(true);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const [form, setForm] = useState({
    subject: '',
    title: '',
    contentType: 'material' as 'material' | 'test',
    bodyText: '',
  });

  async function loadItems() {
    setLoadingItems(true);
    try {
      const res = await fetch('/api/materials?mine=1');
      const json = await res.json().catch(() => null);
      if (res.ok && json?.success) setItems(json.data.items);
    } finally {
      setLoadingItems(false);
    }
  }

  useEffect(() => {
    void loadItems();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaved(false);
    setSaving(true);
    try {
      const res = await fetch('/api/materials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setError(json?.error?.message ?? 'Could not save.');
        return;
      }
      setSaved(true);
      setForm((f) => ({ ...f, title: '', bodyText: '' }));
      await loadItems();
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy-900 dark:text-lavender-50 flex items-center gap-2">
          <Upload className="h-6 w-6 text-purple-600 dark:text-purple-300" /> Materials & Tests
        </h1>
        <p className="text-sm text-navy-500 dark:text-lavender-400">
          Upload study material or tests for a subject. Students in your classes can see materials; tests are used for practice assessments.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, contentType: 'material' }))}
                className={cn(
                  'flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium',
                  form.contentType === 'material' ? 'border-purple-400 bg-purple-50 text-purple-700' : 'border-navy-200 text-navy-600'
                )}
              >
                <FileText className="h-4 w-4" /> Study material
              </button>
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, contentType: 'test' }))}
                className={cn(
                  'flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium',
                  form.contentType === 'test' ? 'border-purple-400 bg-purple-50 text-purple-700' : 'border-navy-200 text-navy-600'
                )}
              >
                <ClipboardList className="h-4 w-4" /> Test
              </button>
            </div>

            <Field label="Subject">
              <input
                required
                value={form.subject}
                onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                className="input"
              />
            </Field>

            <Field label="Title">
              <input
                required
                value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                className="input"
              />
            </Field>

            <Field label={form.contentType === 'test' ? 'Test questions / instructions' : 'Content'}>
              <textarea
                required
                rows={8}
                value={form.bodyText}
                onChange={(e) => setForm((f) => ({ ...f, bodyText: e.target.value }))}
                className="input resize-none"
                placeholder={form.contentType === 'test' ? 'Paste or write the test questions here...' : 'Paste or write the study material here...'}
              />
            </Field>

            {error && <p className="text-sm text-red-600">{error}</p>}
            {saved && (
              <p className="flex items-center gap-1.5 text-sm text-green-700">
                <CheckCircle2 className="h-4 w-4" /> Saved.
              </p>
            )}

            <Button type="submit" disabled={saving} className="w-full">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Upload'}
            </Button>
          </form>
        </Card>

        <Card>
          <CardTitle className="!text-base">Your uploads</CardTitle>
          <CardDescription>Most recent first.</CardDescription>
          <div className="mt-3 space-y-2 max-h-[28rem] overflow-y-auto">
            {loadingItems && <Loader2 className="h-4 w-4 animate-spin text-navy-400" />}
            {!loadingItems && items.length === 0 && <p className="text-sm text-navy-400 dark:text-lavender-500">Nothing uploaded yet.</p>}
            {items.map((item) => (
              <div key={item.id} className="rounded-xl border border-navy-100 dark:border-navy-800 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-navy-800 dark:text-lavender-100">{item.title}</p>
                  <span
                    className={cn(
                      'text-[10px] font-semibold uppercase tracking-wide rounded-full px-2 py-0.5',
                      item.content_type === 'test' ? 'bg-amber-50 text-amber-700' : 'bg-purple-50 text-purple-700'
                    )}
                  >
                    {item.content_type}
                  </span>
                </div>
                <p className="text-xs text-navy-400 dark:text-lavender-500">{item.subject}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(221 225 242);
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
        }
        .input:focus {
          outline: none;
          box-shadow: 0 0 0 2px rgba(151, 105, 216, 0.5);
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-navy-700 dark:text-lavender-200 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
