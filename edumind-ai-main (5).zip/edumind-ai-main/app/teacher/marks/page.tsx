'use client';

import { useState } from 'react';
import { GraduationCap, Search, Loader2, CheckCircle2 } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface FoundStudent {
  id: string;
  register_number: string;
  standard: string | null;
  section: string | null;
  profiles: { full_name: string } | { full_name: string }[] | null;
}

interface MarkRow {
  id: string;
  subject: string;
  exam_name: string;
  marks_obtained: number;
  marks_total: number;
  exam_date: string;
}

function studentName(student: FoundStudent): string {
  const profile = Array.isArray(student.profiles) ? student.profiles[0] : student.profiles;
  return profile?.full_name ?? 'Student';
}

export default function TeacherMarksPage() {
  const [registerNumber, setRegisterNumber] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [student, setStudent] = useState<FoundStudent | null>(null);
  const [marks, setMarks] = useState<MarkRow[]>([]);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const [prediction, setPrediction] = useState<{ expectedScore: number; riskLevel: string; readinessScore: number } | null>(null);

  async function refreshPrediction(currentMarks: MarkRow[]) {
    if (currentMarks.length < 2) {
      setPrediction(null);
      return;
    }
    const scores = currentMarks.map((m) => (m.marks_obtained / m.marks_total) * 100);
    const quizAverage = scores.reduce((a, b) => a + b, 0) / scores.length;
    try {
      const res = await fetch('/api/predictions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          quizAverage,
          masteryAverage: quizAverage,
          completionRate: 70,
          revisionConsistency: 65,
        }),
      });
      const json = await res.json().catch(() => null);
      if (res.ok && json?.success) setPrediction(json.data);
    } catch {
      setPrediction(null);
    }
  }

  const [form, setForm] = useState({
    subject: '',
    examName: '',
    marksObtained: '',
    marksTotal: '100',
    examDate: new Date().toISOString().slice(0, 10),
    notes: '',
  });

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setSearchError(null);
    setSaved(false);
    setSearching(true);
    try {
      const res = await fetch(`/api/teacher/student-lookup?registerNumber=${encodeURIComponent(registerNumber.trim())}`);
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setStudent(null);
        setMarks([]);
        setSearchError(json?.error?.message ?? 'Student not found.');
        return;
      }
      setStudent(json.data.student);
      const marksRes = await fetch(`/api/teacher/marks?studentId=${json.data.student.id}`);
      const marksJson = await marksRes.json().catch(() => null);
      const foundMarks: MarkRow[] = marksRes.ok && marksJson?.success ? marksJson.data.marks : [];
      setMarks(foundMarks);
      await refreshPrediction(foundMarks);
    } catch {
      setSearchError('Something went wrong searching for that student.');
    } finally {
      setSearching(false);
    }
  }

  async function handleSaveMarks(e: React.FormEvent) {
    e.preventDefault();
    if (!student) return;
    setSaveError(null);
    setSaved(false);
    setSaving(true);
    try {
      const res = await fetch('/api/teacher/marks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student.id,
          subject: form.subject,
          examName: form.examName,
          marksObtained: Number(form.marksObtained),
          marksTotal: Number(form.marksTotal),
          examDate: form.examDate,
          notes: form.notes,
        }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setSaveError(json?.error?.message ?? 'Could not save marks.');
        return;
      }
      setSaved(true);
      const updatedMarks = [
        {
          id: crypto.randomUUID(),
          subject: form.subject,
          exam_name: form.examName,
          marks_obtained: Number(form.marksObtained),
          marks_total: Number(form.marksTotal),
          exam_date: form.examDate,
        },
        ...marks,
      ];
      setMarks(updatedMarks);
      await refreshPrediction(updatedMarks);
      setForm((f) => ({ ...f, marksObtained: '', notes: '' }));
    } catch {
      setSaveError('Something went wrong saving marks.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy-900 dark:text-lavender-50 flex items-center gap-2">
          <GraduationCap className="h-6 w-6 text-purple-600 dark:text-purple-300" /> Marks Entry
        </h1>
        <p className="text-sm text-navy-500 dark:text-lavender-400">
          Look up a student by register number, then enter marks for a named exam or update their gradebook.
        </p>
      </div>

      <Card>
        <form onSubmit={handleSearch} className="flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[220px]">
            <label className="block text-sm font-medium text-navy-700 dark:text-lavender-200 mb-1.5">Student register number</label>
            <input
              required
              value={registerNumber}
              onChange={(e) => setRegisterNumber(e.target.value)}
              placeholder="e.g. 2026CS045"
              className="w-full rounded-xl border border-navy-200 dark:border-navy-700 bg-white dark:bg-navy-900 px-3.5 py-2.5 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-200"
            />
          </div>
          <Button type="submit" disabled={searching}>
            {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />} Find student
          </Button>
        </form>
        {searchError && <p className="mt-3 text-sm text-red-600">{searchError}</p>}
      </Card>

      {student && (
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardTitle>{studentName(student)}</CardTitle>
            <CardDescription>
              Register no. {student.register_number} · {student.standard ?? '—'} {student.section ?? ''}
            </CardDescription>

            <form onSubmit={handleSaveMarks} className="mt-5 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Field label="Subject">
                  <input
                    required
                    value={form.subject}
                    onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                    className="input"
                  />
                </Field>
                <Field label="Exam name">
                  <input
                    required
                    placeholder="e.g. Mid-sem, Unit Test 2, End-sem"
                    value={form.examName}
                    onChange={(e) => setForm((f) => ({ ...f, examName: e.target.value }))}
                    className="input"
                  />
                </Field>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <Field label="Marks obtained">
                  <input
                    required
                    type="number"
                    min={0}
                    value={form.marksObtained}
                    onChange={(e) => setForm((f) => ({ ...f, marksObtained: e.target.value }))}
                    className="input"
                  />
                </Field>
                <Field label="Out of">
                  <input
                    required
                    type="number"
                    min={1}
                    value={form.marksTotal}
                    onChange={(e) => setForm((f) => ({ ...f, marksTotal: e.target.value }))}
                    className="input"
                  />
                </Field>
                <Field label="Exam date">
                  <input
                    type="date"
                    value={form.examDate}
                    onChange={(e) => setForm((f) => ({ ...f, examDate: e.target.value }))}
                    className="input"
                  />
                </Field>
              </div>
              <Field label="Notes (optional)">
                <textarea
                  rows={2}
                  value={form.notes}
                  onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                  className="input resize-none"
                />
              </Field>

              {saveError && <p className="text-sm text-red-600">{saveError}</p>}
              {saved && (
                <p className="flex items-center gap-1.5 text-sm text-green-700">
                  <CheckCircle2 className="h-4 w-4" /> Saved. This feeds directly into the student's readiness prediction.
                </p>
              )}

              <Button type="submit" disabled={saving} className="w-full">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save marks'}
              </Button>
            </form>
          </Card>

          <Card>
            <CardTitle className="!text-base">Gradebook history</CardTitle>
            {prediction && (
              <div className="mt-3 rounded-xl border border-purple-100 bg-purple-50 p-3">
                <p className="text-xs font-medium text-purple-700">AI predicted next score</p>
                <p className="text-xl font-display font-semibold text-purple-800">{Math.round(prediction.expectedScore)}%</p>
                <p className="text-xs text-purple-600 mt-0.5">
                  Readiness {Math.round(prediction.readinessScore)}% · {prediction.riskLevel} risk
                </p>
              </div>
            )}
            <div className="mt-3 space-y-2 max-h-96 overflow-y-auto">
              {marks.length === 0 && <p className="text-sm text-navy-400 dark:text-lavender-500">No marks recorded yet.</p>}
              {marks.map((m) => (
                <div key={m.id} className="rounded-xl border border-navy-100 dark:border-navy-800 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-navy-800 dark:text-lavender-100">{m.subject}</p>
                    <p
                      className={`text-sm font-semibold ${
                        (m.marks_obtained / m.marks_total) * 100 < 60 ? 'text-red-500' : 'text-navy-800 dark:text-lavender-100'
                      }`}
                    >
                      {m.marks_obtained}/{m.marks_total}
                    </p>
                  </div>
                  <p className="text-xs text-navy-400 dark:text-lavender-500">
                    {m.exam_name} · {m.exam_date}
                  </p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(221 225 242);
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
        }
        .input:focus {
          outline: none;
          box-shadow: 0 0 0 2px rgba(151, 105, 216, 0.5);
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-navy-700 dark:text-lavender-200 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
