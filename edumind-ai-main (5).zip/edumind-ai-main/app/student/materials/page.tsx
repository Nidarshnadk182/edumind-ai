'use client';

import { useEffect, useState } from 'react';
import { Upload, ThumbsDown, FileText, ClipboardList, Loader2, CheckCircle2 } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ContentItem {
  id: string;
  subject: string;
  content_type: 'material' | 'test';
  title: string;
  body_text: string;
}

interface DifficultyTag {
  id: string;
  subject: string;
  topic: string;
  difficulty_level: 'easy' | 'moderate' | 'hard';
  note: string;
}

const LEVELS = [
  { value: 'hard', label: 'Hard' },
  { value: 'moderate', label: 'Moderate' },
  { value: 'easy', label: 'Easy' },
] as const;

export default function StudentMaterialsPage() {
  const [tags, setTags] = useState<DifficultyTag[]>([]);
  const [ownItems, setOwnItems] = useState<ContentItem[]>([]);
  const [teacherItems, setTeacherItems] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(true);

  const [tagForm, setTagForm] = useState<{ subject: string; topic: string; difficultyLevel: 'easy' | 'moderate' | 'hard'; note: string }>({
    subject: '',
    topic: '',
    difficultyLevel: 'hard',
    note: '',
  });
  const [materialForm, setMaterialForm] = useState({ subject: '', title: '', bodyText: '' });

  const [savingTag, setSavingTag] = useState(false);
  const [savingMaterial, setSavingMaterial] = useState(false);
  const [tagSaved, setTagSaved] = useState(false);
  const [materialSaved, setMaterialSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadAll() {
    setLoading(true);
    try {
      const [tagsRes, ownRes, teacherRes] = await Promise.all([
        fetch('/api/student/difficulty'),
        fetch('/api/materials?mine=1'),
        fetch('/api/materials'),
      ]);
      const [tagsJson, ownJson, teacherJson] = await Promise.all([tagsRes.json(), ownRes.json(), teacherRes.json()]);
      if (tagsRes.ok && tagsJson?.success) setTags(tagsJson.data.items);
      if (ownRes.ok && ownJson?.success) setOwnItems(ownJson.data.items);
      if (teacherRes.ok && teacherJson?.success) {
        setTeacherItems(teacherJson.data.items);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadAll();
  }, []);

  async function handleTagSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setTagSaved(false);
    setSavingTag(true);
    try {
      const res = await fetch('/api/student/difficulty', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tagForm),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setError(json?.error?.message ?? 'Could not save.');
        return;
      }
      setTagSaved(true);
      setTagForm((f) => ({ ...f, topic: '', note: '' }));
      await loadAll();
    } catch {
      setError('Something went wrong.');
    } finally {
      setSavingTag(false);
    }
  }

  async function handleMaterialSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setMaterialSaved(false);
    setSavingMaterial(true);
    try {
      const res = await fetch('/api/materials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...materialForm, contentType: 'material' }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setError(json?.error?.message ?? 'Could not save.');
        return;
      }
      setMaterialSaved(true);
      setMaterialForm({ subject: '', title: '', bodyText: '' });
      await loadAll();
    } catch {
      setError('Something went wrong.');
    } finally {
      setSavingMaterial(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy-900 dark:text-lavender-50 flex items-center gap-2">
          <Upload className="h-6 w-6 text-purple-600 dark:text-purple-300" /> My Materials & Difficulty
        </h1>
        <p className="text-sm text-navy-500 dark:text-lavender-400">
          Tell EduMind what you find difficult, add your own notes, and browse material your teachers have shared.
        </p>
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardTitle className="!text-base flex items-center gap-2">
            <ThumbsDown className="h-4 w-4 text-purple-600" /> Tell the AI what's hard
          </CardTitle>
          <CardDescription>This directly shapes your recommendations, study plan and adaptive tests.</CardDescription>

          <form onSubmit={handleTagSubmit} className="mt-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Field label="Subject">
                <input
                  required
                  value={tagForm.subject}
                  onChange={(e) => setTagForm((f) => ({ ...f, subject: e.target.value }))}
                  className="input"
                />
              </Field>
              <Field label="Chapter / topic (optional)">
                <input
                  value={tagForm.topic}
                  onChange={(e) => setTagForm((f) => ({ ...f, topic: e.target.value }))}
                  className="input"
                />
              </Field>
            </div>

            <Field label="How difficult?">
              <div className="grid grid-cols-3 gap-2">
                {LEVELS.map((lvl) => (
                  <button
                    key={lvl.value}
                    type="button"
                    onClick={() => setTagForm((f) => ({ ...f, difficultyLevel: lvl.value }))}
                    className={cn(
                      'rounded-xl border px-3 py-2 text-sm font-medium',
                      tagForm.difficultyLevel === lvl.value ? 'border-purple-400 bg-purple-50 text-purple-700' : 'border-navy-200 text-navy-600'
                    )}
                  >
                    {lvl.label}
                  </button>
                ))}
              </div>
            </Field>

            <Field label="What specifically trips you up? (optional)">
              <textarea
                rows={2}
                value={tagForm.note}
                onChange={(e) => setTagForm((f) => ({ ...f, note: e.target.value }))}
                className="input resize-none"
              />
            </Field>

            {tagSaved && (
              <p className="flex items-center gap-1.5 text-sm text-green-700">
                <CheckCircle2 className="h-4 w-4" /> Saved.
              </p>
            )}

            <Button type="submit" disabled={savingTag} className="w-full">
              {savingTag ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save'}
            </Button>
          </form>

          <div className="mt-5 space-y-2 max-h-56 overflow-y-auto">
            {tags.map((t) => (
              <div key={t.id} className="rounded-xl border border-navy-100 dark:border-navy-800 p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-navy-800 dark:text-lavender-100">
                    {t.subject}
                    {t.topic ? ` — ${t.topic}` : ''}
                  </p>
                  {t.note && <p className="text-xs text-navy-400 dark:text-lavender-500">{t.note}</p>}
                </div>
                <span
                  className={cn(
                    'text-[10px] font-semibold uppercase tracking-wide rounded-full px-2 py-0.5 shrink-0',
                    t.difficulty_level === 'hard' && 'bg-red-50 text-red-700',
                    t.difficulty_level === 'moderate' && 'bg-amber-50 text-amber-700',
                    t.difficulty_level === 'easy' && 'bg-green-50 text-green-700'
                  )}
                >
                  {t.difficulty_level}
                </span>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardTitle className="!text-base flex items-center gap-2">
              <FileText className="h-4 w-4 text-purple-600" /> Add your own study material
            </CardTitle>
            <form onSubmit={handleMaterialSubmit} className="mt-4 space-y-4">
              <Field label="Subject">
                <input
                  required
                  value={materialForm.subject}
                  onChange={(e) => setMaterialForm((f) => ({ ...f, subject: e.target.value }))}
                  className="input"
                />
              </Field>
              <Field label="Title">
                <input
                  required
                  value={materialForm.title}
                  onChange={(e) => setMaterialForm((f) => ({ ...f, title: e.target.value }))}
                  className="input"
                />
              </Field>
              <Field label="Notes">
                <textarea
                  required
                  rows={4}
                  value={materialForm.bodyText}
                  onChange={(e) => setMaterialForm((f) => ({ ...f, bodyText: e.target.value }))}
                  className="input resize-none"
                />
              </Field>
              {materialSaved && (
                <p className="flex items-center gap-1.5 text-sm text-green-700">
                  <CheckCircle2 className="h-4 w-4" /> Saved to your materials.
                </p>
              )}
              <Button type="submit" disabled={savingMaterial} className="w-full">
                {savingMaterial ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save note'}
              </Button>
            </form>
          </Card>

          <Card>
            <CardTitle className="!text-base flex items-center gap-2">
              <ClipboardList className="h-4 w-4 text-purple-600" /> Shared by your teachers
            </CardTitle>
            <div className="mt-3 space-y-2 max-h-72 overflow-y-auto">
              {loading && <Loader2 className="h-4 w-4 animate-spin text-navy-400" />}
              {!loading && teacherItems.length === 0 && (
                <p className="text-sm text-navy-400 dark:text-lavender-500">Nothing shared yet.</p>
              )}
              {teacherItems.map((item) => (
                <div key={item.id} className="rounded-xl border border-navy-100 dark:border-navy-800 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-navy-800 dark:text-lavender-100">{item.title}</p>
                    <span
                      className={cn(
                        'text-[10px] font-semibold uppercase tracking-wide rounded-full px-2 py-0.5',
                        item.content_type === 'test' ? 'bg-amber-50 text-amber-700' : 'bg-purple-50 text-purple-700'
                      )}
                    >
                      {item.content_type}
                    </span>
                  </div>
                  <p className="text-xs text-navy-400 dark:text-lavender-500">{item.subject}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(221 225 242);
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
        }
        .input:focus {
          outline: none;
          box-shadow: 0 0 0 2px rgba(151, 105, 216, 0.5);
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-navy-700 dark:text-lavender-200 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
