'use client';

import { useEffect, useState } from 'react';
import { Award, TrendingUp, AlertTriangle, UserPlus, Loader2 } from 'lucide-react';
import { Card, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface Mark {
  subject: string;
  exam_name: string;
  marks_obtained: number;
  marks_total: number;
  exam_date: string;
}

interface Prediction {
  expectedScore: number;
  scoreRange: { low: number; high: number };
  riskLevel: 'low' | 'medium' | 'high';
  readinessScore: number;
}

interface Child {
  id: string;
  fullName: string;
  registerNumber: string;
  standard: string | null;
  section: string | null;
  marks: Mark[];
  avgScore: number;
  prediction: Prediction | null;
}

const RISK_STYLES: Record<string, string> = {
  low: 'bg-green-50 text-green-700',
  medium: 'bg-amber-50 text-amber-700',
  high: 'bg-red-50 text-red-700',
};

export default function ParentDashboardPage() {
  const [children, setChildren] = useState<Child[]>([]);
  const [loading, setLoading] = useState(true);
  const [linkRegisterNumber, setLinkRegisterNumber] = useState('');
  const [linking, setLinking] = useState(false);
  const [linkError, setLinkError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch('/api/parent/children');
      const json = await res.json().catch(() => null);
      if (res.ok && json?.success) setChildren(json.data.children);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function handleLinkChild(e: React.FormEvent) {
    e.preventDefault();
    setLinkError(null);
    setLinking(true);
    try {
      const res = await fetch('/api/parent/link-child', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ registerNumber: linkRegisterNumber.trim() }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        setLinkError(json?.error?.message ?? 'Could not link that student.');
        return;
      }
      setLinkRegisterNumber('');
      await load();
    } catch {
      setLinkError('Something went wrong. Please try again.');
    } finally {
      setLinking(false);
    }
  }

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy-900 dark:text-lavender-50">Your Children</h1>
        <p className="text-sm text-navy-500 dark:text-lavender-400">Marks and AI readiness predictions, updated as new marks are entered.</p>
      </div>

      <div className="rounded-xl bg-lavender-50 dark:bg-navy-900/40 border border-lavender-200 dark:border-navy-800 p-4 text-sm text-navy-600 dark:text-lavender-300">
        Private AI-tutor conversations are not shown here, to protect student privacy.
      </div>

      <Card>
        <CardTitle className="!text-base flex items-center gap-2">
          <UserPlus className="h-4 w-4 text-purple-600" /> Link another child
        </CardTitle>
        <form onSubmit={handleLinkChild} className="mt-3 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[220px]">
            <input
              required
              value={linkRegisterNumber}
              onChange={(e) => setLinkRegisterNumber(e.target.value)}
              placeholder="Child's register number"
              className="w-full rounded-xl border border-navy-200 dark:border-navy-700 bg-white dark:bg-navy-900 px-3.5 py-2.5 text-sm outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-200"
            />
          </div>
          <Button type="submit" disabled={linking}>
            {linking ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Link child'}
          </Button>
        </form>
        {linkError && <p className="mt-2 text-sm text-red-600">{linkError}</p>}
      </Card>

      {loading && (
        <div className="flex items-center gap-2 text-navy-400">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading...
        </div>
      )}

      {!loading && children.length === 0 && (
        <Card>
          <p className="text-sm text-navy-500 dark:text-lavender-400">
            No children linked yet. Enter your child's register number above to see their progress.
          </p>
        </Card>
      )}

      {children.map((child) => (
        <Card key={child.id}>
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <CardTitle>{child.fullName}</CardTitle>
              <CardDescription>
                Register no. {child.registerNumber} · {child.standard ?? '—'} {child.section ?? ''}
              </CardDescription>
            </div>
            {child.prediction && (
              <span className={`rounded-full px-3 py-1 text-xs font-semibold ${RISK_STYLES[child.prediction.riskLevel]}`}>
                {child.prediction.riskLevel} risk
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
            <StatCard icon={Award} label="Average score" value={`${child.avgScore}%`} />
            {child.prediction ? (
              <>
                <StatCard icon={TrendingUp} label="Predicted next score" value={`${Math.round(child.prediction.expectedScore)}%`} />
                <StatCard
                  icon={TrendingUp}
                  label="Expected range"
                  value={`${Math.round(child.prediction.scoreRange.low)}–${Math.round(child.prediction.scoreRange.high)}%`}
                />
                <StatCard icon={TrendingUp} label="Readiness" value={`${Math.round(child.prediction.readinessScore)}%`} />
              </>
            ) : (
              <div className="col-span-3 flex items-center gap-2 rounded-xl border border-amber-100 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                We need at least two recorded exams before we can estimate a readiness score.
              </div>
            )}
          </div>

          <div className="mt-5">
            <p className="text-sm font-medium text-navy-700 dark:text-lavender-200 mb-2">Recent marks</p>
            <div className="space-y-1.5">
              {child.marks.length === 0 && <p className="text-sm text-navy-400 dark:text-lavender-500">No marks recorded yet.</p>}
              {child.marks.slice(0, 6).map((m, i) => (
                <div key={i} className="flex items-center justify-between text-sm border-b border-navy-50 dark:border-navy-800/60 pb-1.5 last:border-0">
                  <span className="text-navy-600 dark:text-lavender-300">
                    {m.subject} — {m.exam_name}
                  </span>
                  <span
                    className={`font-medium ${
                      (m.marks_obtained / m.marks_total) * 100 < 60 ? 'text-red-500' : 'text-navy-800 dark:text-lavender-100'
                    }`}
                  >
                    {m.marks_obtained}/{m.marks_total}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: typeof Award; label: string; value: string }) {
  return (
    <Card className="!p-4">
      <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-purple-50 text-purple-600 dark:bg-navy-800 dark:text-purple-300 mb-2">
        <Icon className="h-4 w-4" />
      </span>
      <p className="text-lg font-display font-semibold text-navy-900 dark:text-lavender-50">{value}</p>
      <p className="text-xs text-navy-500 dark:text-lavender-400">{label}</p>
    </Card>
  );
}
