'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Brain, GraduationCap, School, Building2, Users } from 'lucide-react';

type Role = 'student' | 'teacher' | 'parent' | 'institution';

const ROLE_OPTIONS: Array<{
  role: Role;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  {
    role: 'student',
    title: 'Student',
    description: 'AI Tutor, quizzes, weak-topic tracking and a personalised study plan.',
    icon: GraduationCap,
  },
  {
    role: 'parent',
    title: 'Parent',
    description: "Follow your child's progress, weak topics and predicted exam scores.",
    icon: Users,
  },
  {
    role: 'teacher',
    title: 'Teacher',
    description: 'Enter marks, upload material and tests, and track your class.',
    icon: School,
  },
  {
    role: 'institution',
    title: 'Institution Admin',
    description: 'Manage teachers and students, view institution-wide analytics.',
    icon: Building2,
  },
];

export default function RolePickerPage() {
  const router = useRouter();

  function chooseRole(role: Role) {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('edumind_selected_role', role);
    }
    router.push('/login?mode=signup');
  }

  return (
    <main className="min-h-screen bg-canvas-light px-6 py-12">
      <div className="mx-auto w-full max-w-3xl">
        <Link
          href="/"
          className="mb-8 flex items-center justify-center gap-2 font-display font-semibold text-navy-900"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600 text-white">
            <Brain className="h-5 w-5" />
          </span>
          <span className="text-lg">EduMind AI</span>
        </Link>

        <section className="card p-7 md:p-9">
          <div className="mx-auto mb-8 max-w-xl text-center">
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.15em] text-purple-600">Get started</p>
            <h1 className="font-display text-2xl font-semibold text-navy-900 md:text-3xl">
              Who&apos;s signing up?
            </h1>
            <p className="mt-3 text-sm leading-6 text-navy-500">
              Choose how you&apos;ll use EduMind AI. You&apos;ll create your login next.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ROLE_OPTIONS.map(({ role, title, description, icon: Icon }) => (
              <button
                key={role}
                type="button"
                onClick={() => chooseRole(role)}
                className="group relative rounded-2xl border border-navy-200 bg-white p-5 text-left transition-all hover:border-purple-300 hover:shadow-sm"
              >
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-purple-600 group-hover:bg-purple-600 group-hover:text-white">
                  <Icon className="h-5 w-5" />
                </div>
                <h2 className="font-display text-base font-semibold text-navy-900">{title}</h2>
                <p className="mt-2 text-sm leading-6 text-navy-500">{description}</p>
              </button>
            ))}
          </div>

          <p className="mt-7 text-center text-sm text-navy-500">
            Already have an account?{' '}
            <Link href="/login" className="font-medium text-purple-600 hover:text-purple-700">
              Log in
            </Link>
          </p>
        </section>
      </div>
    </main>
  );
}
