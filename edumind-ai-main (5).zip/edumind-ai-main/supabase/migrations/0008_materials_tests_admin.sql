-- ─────────────────────────────────────────────────────────
-- EduMind AI — Subject-level materials/tests uploaded by
-- teachers or students, and institution admin management
-- ─────────────────────────────────────────────────────────

-- Lightweight subject-level content, separate from the
-- topic-scoped `learning_materials` table. Used for both
-- teacher-uploaded study material / tests, and material a
-- student adds for themselves.
create table if not exists subject_content (
  id uuid primary key default uuid_generate_v4(),
  owner_profile_id uuid not null references profiles(id) on delete cascade,
  subject text not null,
  content_type text not null default 'material' check (content_type in ('material', 'test')),
  title text not null,
  storage_path text,
  body_text text default '',
  visible_to_students boolean not null default true,
  class_id uuid references classes(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_subject_content_owner on subject_content(owner_profile_id);
create index if not exists idx_subject_content_subject on subject_content(subject);
create index if not exists idx_subject_content_class on subject_content(class_id);

alter table subject_content enable row level security;

drop policy if exists "owner manages own subject content" on subject_content;
create policy "owner manages own subject content" on subject_content
  for all using (owner_profile_id = auth.uid())
  with check (owner_profile_id = auth.uid());

drop policy if exists "students read visible class material" on subject_content;
create policy "students read visible class material" on subject_content
  for select using (
    visible_to_students = true
    and (
      class_id is null
      or class_id in (
        select cm.class_id from class_members cm
        join student_profiles sp on sp.id = cm.student_id
        where sp.profile_id = auth.uid()
      )
    )
  );

-- One institution per admin account, so onboarding can upsert safely.
create unique index if not exists idx_institutions_admin_unique on institutions(admin_profile_id);

-- Institution admin: which students/teachers belong to it,
-- so the admin can add/remove users.
alter table teacher_profiles
  add column if not exists added_by_institution_id uuid references institutions(id) on delete set null;

alter table student_profiles
  add column if not exists institution_id uuid references institutions(id) on delete set null;

create index if not exists idx_student_profiles_institution on student_profiles(institution_id);

drop policy if exists "institution admin reads its teachers" on teacher_profiles;
create policy "institution admin reads its teachers" on teacher_profiles
  for select using (
    institution_id in (select id from institutions where admin_profile_id = auth.uid())
  );

drop policy if exists "institution admin reads its students" on student_profiles;
create policy "institution admin reads its students" on student_profiles
  for select using (
    institution_id in (select id from institutions where admin_profile_id = auth.uid())
  );
