-- ─────────────────────────────────────────────────────────
-- EduMind AI — Role-first signup fields, parent linking,
-- teacher marks entry, student difficulty tagging
-- ─────────────────────────────────────────────────────────

-- Student identity fields collected at signup
alter table student_profiles
  add column if not exists register_number text,
  add column if not exists standard text,
  add column if not exists section text;

create unique index if not exists idx_student_profiles_register_number
  on student_profiles(register_number)
  where register_number is not null;

-- Parent profile: contact details + which child(ren) they can view
create table if not exists parent_profiles (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid not null unique references profiles(id) on delete cascade,
  contact_number text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_parent_profiles_updated_at on parent_profiles;
create trigger trg_parent_profiles_updated_at before update on parent_profiles
  for each row execute function set_updated_at();

-- Institution admin: name of institution collected at signup
alter table institutions
  add column if not exists contact_email text;

-- Teacher-entered marks for a student, in a subject/exam
create table if not exists teacher_subject_marks (
  id uuid primary key default uuid_generate_v4(),
  teacher_id uuid not null references teacher_profiles(id) on delete cascade,
  student_id uuid not null references student_profiles(id) on delete cascade,
  subject text not null,
  exam_name text not null,
  marks_obtained numeric(6,2) not null,
  marks_total numeric(6,2) not null default 100,
  exam_date date not null default current_date,
  notes text default '',
  created_at timestamptz not null default now()
);

create index if not exists idx_teacher_marks_student on teacher_subject_marks(student_id);
create index if not exists idx_teacher_marks_teacher on teacher_subject_marks(teacher_id);
create index if not exists idx_teacher_marks_subject on teacher_subject_marks(student_id, subject);

-- Student self-reported difficulty per subject/topic, used by the AI
-- tutor and the recommendation/prediction engines.
create table if not exists student_topic_difficulty (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references student_profiles(id) on delete cascade,
  subject text not null,
  topic text not null default '',
  difficulty_level text not null default 'hard' check (difficulty_level in ('easy','moderate','hard')),
  note text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_student_difficulty_student on student_topic_difficulty(student_id);

drop trigger if exists trg_student_difficulty_updated_at on student_topic_difficulty;
create trigger trg_student_difficulty_updated_at before update on student_topic_difficulty
  for each row execute function set_updated_at();

-- Row level security for the new tables
alter table parent_profiles enable row level security;
alter table teacher_subject_marks enable row level security;
alter table student_topic_difficulty enable row level security;

drop policy if exists "parent can manage own profile" on parent_profiles;
create policy "parent can manage own profile" on parent_profiles
  for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());

drop policy if exists "teacher manages marks they entered" on teacher_subject_marks;
create policy "teacher manages marks they entered" on teacher_subject_marks
  for all using (
    teacher_id in (select id from teacher_profiles where profile_id = auth.uid())
  ) with check (
    teacher_id in (select id from teacher_profiles where profile_id = auth.uid())
  );

drop policy if exists "student reads own marks" on teacher_subject_marks;
create policy "student reads own marks" on teacher_subject_marks
  for select using (
    student_id in (select id from student_profiles where profile_id = auth.uid())
  );

drop policy if exists "parent reads linked child marks" on teacher_subject_marks;
create policy "parent reads linked child marks" on teacher_subject_marks
  for select using (
    student_id in (
      select sp.id from student_profiles sp
      join parent_student_links psl on psl.student_profile_id = sp.profile_id
      where psl.parent_profile_id = auth.uid() and psl.consent_confirmed = true
    )
  );

drop policy if exists "student manages own difficulty tags" on student_topic_difficulty;
create policy "student manages own difficulty tags" on student_topic_difficulty
  for all using (
    student_id in (select id from student_profiles where profile_id = auth.uid())
  ) with check (
    student_id in (select id from student_profiles where profile_id = auth.uid())
  );

drop policy if exists "teacher reads difficulty tags of own students" on student_topic_difficulty;
create policy "teacher reads difficulty tags of own students" on student_topic_difficulty
  for select using (
    student_id in (
      select cm.student_id from class_members cm
      join classes c on c.id = cm.class_id
      join teacher_profiles tp on tp.id = c.teacher_id
      where tp.profile_id = auth.uid()
    )
  );
